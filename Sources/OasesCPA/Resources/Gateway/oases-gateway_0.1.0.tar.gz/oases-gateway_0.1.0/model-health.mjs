// "Does this model answer right now?": one minimal chat request per model (or per provider
// serving a model), the stored outcome of the latest request, and a bulk run over every model.
//
// Requests go straight to the engine with the gateway's internal key, never through the
// gateway's own key checks, so a result says whether the engine can serve the model, not
// whether some API key may use it. A request is the same tiny body every time:
//   { model, messages: [{ role: 'user', content: 'ping' }], max_tokens: 16, stream: false }
//
//   * testModel(model)             the bare id: the engine picks the provider as it always does.
//   * testProvider(provider, model) "<prefix>/<model>": only that provider (see provider-routing.mjs).
//                                   A provider without a prefix cannot be addressed alone: down,
//                                   no request.
//   * startTestAll(models)         at most `concurrency` requests at a time, one run at a time.
//
// Every probe has a deadline that holds even if the fetch implementation ignores its abort
// signal, so one model that never answers costs one slot for `timeoutMs`, not the whole run.
//
// Results live in a JSON file (0600, written to a temporary file and renamed), so a crash or a
// full disk can leave the previous file behind but never a half-written one. A run is only kept
// in memory: after a restart nothing is running. Writing the file is synchronous, so the results
// of a run are written together: at most once per `persistDelayMs` while it goes on, and once
// more when it ends. A single test is written at once (with anything still waiting).
import crypto from 'node:crypto';
import nodeFs from 'node:fs';
import nodePath from 'node:path';

import { isPrefixUnique, routeModelId } from './provider-routing.mjs';

// Models that do not answer a chat request: not tested, shown as "not applicable".
export const SKIP_MODEL_PATTERN = /image|embed|tts|whisper|audio|sora|veo|imagen|video|search|sonar|rerank|moderation/i;

export const ERROR_MAX_CHARS = 120;
const DEFAULT_CONCURRENCY = 4;
const DEFAULT_TIMEOUT_MS = 60_000;
const DEFAULT_PERSIST_DELAY_MS = 1000;
const RAW_ERROR_MAX_CHARS = 4000;
const STORE_VERSION = 1;
const STATUSES = new Set(['up', 'down', 'skipped']);
const MASK = '***';

const isPlainObject = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value);

// ------------------------------------------------------------------ error text

// Strings that look like credentials, replaced before the text is stored or shown. The upstream
// can quote the key it was called with ("Incorrect API key provided: sk-…"), a bearer header or
// a URL with ?key=…; none of that may reach the panel or the results file.
// A model id such as "qwen3-235b-a22b-instruct-2507-fp8": lower case, at least two "-"-separated
// parts of at most 10 characters, one of them a plain word. Credentials do not look like that,
// so such a token is kept even when it is long and mixes letters with digits.
const looksLikeModelId = (token) => {
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)+$/.test(token)) return false;
  const parts = token.split('-');
  return parts.every((part) => part.length <= 10) && parts.some((part) => /^[a-z]{2,}$/.test(part));
};

const KEY_LIKE = [
  [/\bBearer\s+[A-Za-z0-9._~+/=-]+/gi, MASK],
  [/\bBasic\s+[A-Za-z0-9+/=._-]{4,}/gi, MASK],
  [/([?&](?:api[_-]?key|key|token|access[_-]?token|secret)=)[^&\s"'<>]+/gi, `$1${MASK}`],
  // "api_key: …", "api-key=\"…\"", "secret: …" in a quoted config or message.
  [/(\b(?:api[_-]?key|access[_-]?token|secret|password|token|key)["']?\s*[:=]\s*["']?)(?!\*\*\*)[^\s"'&,;<>{}]+/gi, `$1${MASK}`],
  [/\b(?:sk|pk|rk)[-_][A-Za-z0-9*][A-Za-z0-9._*-]{5,}/gi, MASK],
  [/\beyJ[A-Za-z0-9_-]{5,}(?:\.[A-Za-z0-9_-]+){0,2}/g, MASK],
  [/\bAIza[0-9A-Za-z_-]{20,}/g, MASK],
  [/\bgh[pousr]_[A-Za-z0-9]{20,}/g, MASK],
  [/\bxox[abprs]-[A-Za-z0-9-]{10,}/g, MASK],
  [/\bAKIA[0-9A-Z]{16}\b/g, MASK],
  // Any long run of letters, digits, "_" and "-" that mixes letters with digits.
  [/\b(?=[A-Za-z0-9_-]*\d)(?=[A-Za-z0-9_-]*[A-Za-z])[A-Za-z0-9_-]{32,}\b/g, (token) => (looksLikeModelId(token) ? token : MASK)],
];

/**
 * The text of an upstream error as it may be stored: key-like strings (and the exact secrets
 * given) masked, whitespace folded to single spaces, then cut to the first 120 characters.
 * Masking comes first so a key that straddles the cut cannot leave a readable fragment.
 */
export function cleanErrorText(raw, secrets = []) {
  let text = String(raw ?? '').slice(0, RAW_ERROR_MAX_CHARS);
  for (const secret of secrets) {
    if (typeof secret === 'string' && secret.length >= 6) text = text.split(secret).join(MASK);
  }
  for (const [pattern, replacement] of KEY_LIKE) text = text.replace(pattern, replacement);
  text = text.replace(/\s+/g, ' ').trim();
  return Array.from(text).slice(0, ERROR_MAX_CHARS).join('');
}

// The body is always read to the end so the connection is freed; a stand-in response that only
// offers json() is accepted too.
async function readBody(response) {
  if (typeof response.text === 'function') return response.text();
  if (typeof response.json === 'function') return JSON.stringify(await response.json());
  return '';
}

const firstText = (...values) => values.find((value) => typeof value === 'string' && value.trim()) || '';

// The message inside the usual error bodies; anything unrecognised is used as it is.
function upstreamMessage(bodyText) {
  const raw = String(bodyText ?? '').trim();
  if (!raw) return '';
  let parsed = null;
  try {
    parsed = JSON.parse(raw);
  } catch { /* not JSON: use the text */ }
  if (isPlainObject(parsed)) {
    const found = firstText(
      parsed.error?.message,
      parsed.error,
      parsed.message,
      parsed.detail,
      parsed.error?.detail,
    );
    if (found) return found;
  }
  return raw;
}

// ------------------------------------------------------------------ stored results

function cleanResult(value) {
  if (!isPlainObject(value) || !STATUSES.has(value.status)) return null;
  const finite = (n) => typeof n === 'number' && Number.isFinite(n);
  return {
    status: value.status,
    latency_ms: finite(value.latency_ms) ? value.latency_ms : null,
    error: typeof value.error === 'string' ? value.error : null,
    tested_at: finite(value.tested_at) ? value.tested_at : 0,
  };
}

function cleanMap(value) {
  const map = new Map();
  if (!isPlainObject(value)) return map;
  for (const [key, entry] of Object.entries(value)) {
    const result = cleanResult(entry);
    if (result) map.set(key, result);
  }
  return map;
}

// ------------------------------------------------------------------ the service

export function createModelHealthService({
  path: filePath,
  fetchImpl = globalThis.fetch,
  engineBase,
  engineKey,
  now = Date.now,
  concurrency = DEFAULT_CONCURRENCY,
  timeoutMs = DEFAULT_TIMEOUT_MS,
  readProviders = () => [],
  // Every routing prefix of the engine config (parseConfigPrefixes). When given, a provider whose
  // prefix another entry shares cannot be addressed alone: down, no request.
  readPrefixes = null,
  persistDelayMs = DEFAULT_PERSIST_DELAY_MS,
  fsImpl = nodeFs,
  logger = console,
} = {}) {
  const limit = Number.isInteger(concurrency) && concurrency > 0 ? concurrency : DEFAULT_CONCURRENCY;
  const deadlineMs = Number.isFinite(timeoutMs) && timeoutMs > 0 ? timeoutMs : DEFAULT_TIMEOUT_MS;
  const chatUrl = `${String(engineBase ?? '').replace(/\/+$/, '')}/v1/chat/completions`;
  const persistDelay = Number.isFinite(persistDelayMs) && persistDelayMs >= 0 ? persistDelayMs : DEFAULT_PERSIST_DELAY_MS;

  let models = new Map();
  let providers = new Map();
  let run = null;
  let active = Promise.resolve();

  // ---- storage

  function load() {
    let text;
    try {
      text = fsImpl.readFileSync(filePath, 'utf8');
    } catch (error) {
      if (error?.code !== 'ENOENT') logger.warn?.(`[model-health] could not read ${filePath}: ${error?.message}`);
      return;
    }
    let doc;
    try {
      doc = JSON.parse(text);
    } catch {
      logger.warn?.(`[model-health] ignoring unreadable ${filePath}; it is replaced by the next result`);
      return;
    }
    if (!isPlainObject(doc)) return;
    models = cleanMap(doc.models);
    providers = cleanMap(doc.providers);
  }

  // The whole document goes to a temporary file first and is renamed over the real one, so a
  // failure at any step leaves the previous file untouched. A failure never reaches the caller:
  // the result stays in memory and the next successful write stores it.
  function persist() {
    const tmp = `${filePath}.${process.pid}.${crypto.randomUUID().slice(0, 8)}.tmp`;
    let fd = null;
    try {
      fsImpl.mkdirSync(nodePath.dirname(filePath), { recursive: true, mode: 0o700 });
      fd = fsImpl.openSync(tmp, 'w', 0o600);
      fsImpl.writeFileSync(fd, `${JSON.stringify({
        version: STORE_VERSION,
        models: Object.fromEntries(models),
        providers: Object.fromEntries(providers),
      })}\n`);
      fsImpl.fsyncSync(fd);
      fsImpl.closeSync(fd);
      fd = null;
      fsImpl.renameSync(tmp, filePath);
      fsImpl.chmodSync(filePath, 0o600);
    } catch (error) {
      if (fd !== null) {
        try { fsImpl.closeSync(fd); } catch { /* already closed */ }
      }
      try { fsImpl.unlinkSync(tmp); } catch { /* no temporary file */ }
      logger.error?.(`[model-health] could not store results in ${filePath}: ${error?.message}`);
    }
  }

  // A run's results wait for one timer (started by the first of them, not pushed back by the
  // others); flush() writes whatever is waiting now.
  let persistTimer = null;
  function schedulePersist() {
    if (persistTimer) return;
    persistTimer = setTimeout(() => {
      persistTimer = null;
      persist();
    }, persistDelay);
    persistTimer.unref?.();
  }

  function flush() {
    if (persistTimer) {
      clearTimeout(persistTimer);
      persistTimer = null;
    }
    persist();
  }

  function record(map, key, result, { deferred = false } = {}) {
    map.set(key, result);
    if (deferred) schedulePersist();
    else flush();
    return result;
  }

  load();

  // ---- probing

  function currentKey() {
    const value = typeof engineKey === 'function' ? engineKey() : engineKey;
    const key = typeof value === 'string' ? value.trim() : '';
    if (!key) {
      throw Object.assign(new Error('The internal engine key is not configured.'), { code: 'engine_key_missing' });
    }
    return key;
  }

  const outcome = (status, latency, error, testedAt) => ({ status, latency_ms: latency, error, tested_at: testedAt });

  const timeoutLabel = deadlineMs >= 1000 ? `${Math.round(deadlineMs / 1000)} 秒` : `${deadlineMs} 毫秒`;

  // One request. Resolves to a Result; rejects only when there is no engine key (nothing was sent).
  async function probe(modelId) {
    const key = currentKey();
    const controller = new AbortController();
    let timedOut = false;
    let timer;
    const deadline = new Promise((_, reject) => {
      timer = setTimeout(() => {
        timedOut = true;
        reject(new Error('timeout'));
        controller.abort();
      }, deadlineMs);
      timer.unref?.();
    });
    const started = now();
    try {
      const attempt = (async () => {
        const response = await fetchImpl(chatUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
          body: JSON.stringify({
            model: modelId,
            messages: [{ role: 'user', content: 'ping' }],
            max_tokens: 16,
            stream: false,
          }),
          signal: controller.signal,
        });
        const text = await readBody(response);
        return { response, text };
      })();
      attempt.catch(() => {}); // when the deadline wins, the aborted attempt rejects later
      const { response, text } = await Promise.race([attempt, deadline]);
      const finished = now();
      const status = Number(response.status) || (response.ok ? 200 : 500);
      if (status >= 200 && status < 300) {
        return outcome('up', Math.max(0, finished - started), null, finished);
      }
      const message = cleanErrorText(upstreamMessage(text), [key]) || `HTTP ${status}`;
      return outcome('down', null, message, finished);
    } catch (error) {
      const finished = now();
      if (timedOut) return outcome('down', null, `请求超时（${timeoutLabel}内无响应）`, finished);
      const reason = [error?.cause?.code, error?.message].filter((part) => typeof part === 'string' && part).join(' ');
      return outcome('down', null, cleanErrorText(`请求失败：${reason || '未知错误'}`, [key]), finished);
    } finally {
      clearTimeout(timer);
    }
  }

  function resolveProvider(ref) {
    if (isPlainObject(ref)) return typeof ref.name === 'string' && ref.name ? ref : null;
    if (typeof ref !== 'string' || !ref) return null;
    let list = [];
    try {
      list = readProviders() || [];
    } catch (error) {
      logger.warn?.(`[model-health] provider list unavailable: ${error?.message}`);
    }
    return Array.isArray(list) ? list.find((provider) => provider?.name === ref) || null : null;
  }

  // A list that cannot be read counts as empty, so the prefix is not trusted to be unique.
  function currentPrefixes() {
    try {
      const list = readPrefixes();
      return Array.isArray(list) ? list : [];
    } catch (error) {
      logger.warn?.(`[model-health] routing prefixes unavailable: ${error?.message}`);
      return [];
    }
  }

  const requireModel = (model) => {
    const id = typeof model === 'string' ? model.trim() : '';
    if (!id) throw Object.assign(new Error('A model id is required.'), { code: 'model_required' });
    return id;
  };

  async function testModel(model, { deferred = false } = {}) {
    const id = requireModel(model);
    if (SKIP_MODEL_PATTERN.test(id)) return record(models, id, outcome('skipped', null, null, now()), { deferred });
    return record(models, id, await probe(id), { deferred });
  }

  async function testProvider(providerRef, model) {
    const id = requireModel(model);
    const provider = resolveProvider(providerRef);
    if (!provider) return outcome('down', null, '未找到该供应商', now());
    const storeKey = `${provider.name}|${id}`;
    if (SKIP_MODEL_PATTERN.test(id)) return record(providers, storeKey, outcome('skipped', null, null, now()));
    const routed = routeModelId(provider, id);
    if (!routed) return record(providers, storeKey, outcome('down', null, '该供应商未设置前缀', now()));
    if (typeof readPrefixes === 'function' && !isPrefixUnique(provider.prefix, currentPrefixes())) {
      return record(providers, storeKey, outcome('down', null, '该供应商前缀与其他供应商重复', now()));
    }
    return record(providers, storeKey, await probe(routed));
  }

  // ---- the bulk run

  function startTestAll(modelIds) {
    if (run && run.finished_at === null) return run;
    const list = [...new Set((Array.isArray(modelIds) ? modelIds : [])
      .filter((id) => typeof id === 'string' && id.trim())
      .map((id) => id.trim()))];
    if (list.length) currentKey();
    const state = { id: crypto.randomUUID(), started_at: now(), finished_at: null, total: list.length, done: 0, up: 0, down: 0, skipped: 0 };
    run = state;
    if (!list.length) {
      state.finished_at = now();
      return state;
    }
    const queue = list.slice();
    const worker = async () => {
      for (let model = queue.shift(); model !== undefined; model = queue.shift()) {
        let status = 'down';
        try {
          status = (await testModel(model, { deferred: true })).status;
        } catch (error) {
          // Only a vanished engine key lands here; nothing was sent and nothing is overwritten.
          logger.error?.(`[model-health] ${model} was not tested: ${error?.message}`);
        }
        state.done += 1;
        state[status] += 1;
      }
    };
    // Everything is on disk by the time the run says it has finished.
    const finish = () => {
      flush();
      state.finished_at = now();
    };
    active = Promise.all(Array.from({ length: Math.min(limit, list.length) }, worker)).then(finish, finish);
    return state;
  }

  return {
    get: () => ({ models: Object.fromEntries(models), providers: Object.fromEntries(providers), run }),
    testModel: (model) => testModel(model),
    testProvider,
    startTestAll,
    // Writes the results still waiting for the timer (if any) now.
    flush,
    // Resolves when the run in progress (if any) has finished.
    idle: () => active,
  };
}
