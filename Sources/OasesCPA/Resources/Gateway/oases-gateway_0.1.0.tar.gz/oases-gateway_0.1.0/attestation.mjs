// Software attestation is not part of this gateway.
//
// The production gateway can bind an API key to attested client software. That implementation
// is not published. This stub keeps the same interface so server.mjs needs no special cases,
// and it fails closed: a key whose policy requires attestation is refused on the /v1/* API
// routes (where server.mjs calls gate()), whether its policy says "observe" or "enforce".
// Keys without that requirement are unaffected.

const UNSUPPORTED_MESSAGE = 'This key requires software attestation, which this gateway does not provide.';

function unsupported() {
  return { ok: false, code: 'attestation_unsupported', message: UNSUPPORTED_MESSAGE };
}

/** Same shape as the production service; every option is accepted and ignored. */
export function createAttestationService(options = {}) {
  void options;

  function gate({ policy } = {}) {
    if (policy?.attestation?.required === true) return unsupported();
    return { ok: true, watched: false };
  }

  return {
    issueNonce: () => unsupported(),
    enroll: () => unsupported(),
    gate,
    recordCall: () => {},
    summary: () => ({ apps: [] }),
    devices: () => ({ devices: [] }),
    logs: () => ({ logs: [] }),
    flushSync: () => {},
  };
}
