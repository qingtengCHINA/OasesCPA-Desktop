// Read-only host health snapshot for the admin surface (GET /cpa-admin/host/status).
// Everything here is local and cheap: /proc, `systemctl show`, certificate files,
// release symlinks and the backup job's status file. No secrets are read or returned.
import fsDefault from 'fs';
import crypto from 'crypto';
import os from 'os';
import path from 'path';
import { execFile as execFileDefault } from 'child_process';
import { resolveGatewayPaths } from './paths.mjs';

// No unit is watched unless the operator names it (HOST_STATUS_UNITS, see hostStatusOptionsFromEnv).
// With an empty list the snapshot has no services and systemctl is never run.
export const DEFAULT_HOST_UNITS = Object.freeze([]);

const DEFAULT_CERT_DIRECTORY = '/etc/letsencrypt/live';

/**
 * The host status options an operator can set through the environment:
 *   HOST_STATUS_UNITS           comma-separated systemd units to report (blanks and empty entries dropped)
 *   HOST_STATUS_CERT_DIR        directory with one folder per certificate (default /etc/letsencrypt/live)
 *   HOST_STATUS_ENGINE_LINK     release symlink of the engine binary, whose target names its version
 *   HOST_STATUS_PANEL_LINK      the same for the panel
 *   HOST_STATUS_ENGINE_VERSION  engine version to report; wins over the one read from the link
 *   HOST_STATUS_PANEL_VERSION   the same for the panel
 * A variable that is not set, or empty, or only blanks, counts as unset.
 */
export function hostStatusOptionsFromEnv(env = process.env) {
  const text = (name) => (typeof env[name] === 'string' ? env[name].trim() : '') || null;
  return {
    units: String(env.HOST_STATUS_UNITS ?? '').split(',').map((unit) => unit.trim()).filter(Boolean),
    certDirectory: text('HOST_STATUS_CERT_DIR') ?? DEFAULT_CERT_DIRECTORY,
    engineBinaryLink: text('HOST_STATUS_ENGINE_LINK'),
    panelBinaryLink: text('HOST_STATUS_PANEL_LINK'),
    engineVersion: text('HOST_STATUS_ENGINE_VERSION'),
    panelVersion: text('HOST_STATUS_PANEL_VERSION'),
  };
}

const SYSTEMCTL_PROPERTIES = ['Id', 'ActiveState', 'SubState', 'ActiveEnterTimestamp', 'NRestarts', 'MemoryCurrent', 'Result'];

function parseSystemctlShow(output) {
  return output
    .split(/\n\s*\n/)
    .map((block) => Object.fromEntries(block.split('\n').filter(Boolean).map((line) => {
      const index = line.indexOf('=');
      return [line.slice(0, index), line.slice(index + 1)];
    })))
    .filter((record) => record.Id);
}

function toNumberOrNull(value) {
  const number = Number(value);
  return Number.isFinite(number) && value !== '' && value !== '[not set]' ? number : null;
}

function serviceRecord(record) {
  const since = record.ActiveEnterTimestamp && record.ActiveEnterTimestamp !== 'n/a'
    ? new Date(record.ActiveEnterTimestamp)
    : null;
  const memory = toNumberOrNull(record.MemoryCurrent);
  return {
    unit: record.Id,
    active: record.ActiveState || 'unknown',
    sub: record.SubState || '',
    result: record.Result || '',
    since: since && !Number.isNaN(since.getTime()) ? since.toISOString() : null,
    restarts: toNumberOrNull(record.NRestarts) ?? 0,
    // systemd reports UINT64_MAX when accounting is unavailable.
    memory_bytes: memory !== null && memory < 2 ** 60 ? memory : null,
  };
}

function parseMeminfo(text) {
  const values = {};
  for (const line of text.split('\n')) {
    const match = line.match(/^(\w+):\s+(\d+)\s*kB/);
    if (match) values[match[1]] = Number(match[2]) * 1024;
  }
  return {
    total_bytes: values.MemTotal ?? null,
    available_bytes: values.MemAvailable ?? null,
    swap_total_bytes: values.SwapTotal ?? null,
    swap_used_bytes: values.SwapTotal != null && values.SwapFree != null ? values.SwapTotal - values.SwapFree : null,
  };
}

export function createHostStatusService({
  units = DEFAULT_HOST_UNITS,
  certDirectory = DEFAULT_CERT_DIRECTORY,
  backupStatusPath = resolveGatewayPaths().backupStatusPath,
  // Release symlinks whose target names the installed version. There is no portable default
  // location, so versions stay null until a link or a version is given.
  engineBinaryLink = null,
  panelBinaryLink = null,
  // Versions given outright; they win over the ones read from the links and need no link.
  engineVersion = null,
  panelVersion = null,
  diskPath = '/',
  cacheMs = 5000,
  fs = fsDefault,
  execFile = execFileDefault,
  now = () => Date.now(),
} = {}) {
  let cached = null;
  let inFlight = null;

  const readServices = () => new Promise((resolve) => {
    if (units.length === 0) {
      resolve([]);
      return;
    }
    // "--" ends the options, so a unit whose name starts with "-" is a unit, not an option.
    const args = ['show', `--property=${SYSTEMCTL_PROPERTIES.join(',')}`, '--', ...units];
    execFile('systemctl', args, { timeout: 5000 }, (error, stdout) => {
      if (error && !stdout) {
        resolve(units.map((unit) => ({ unit, active: 'unknown', sub: '', result: '', since: null, restarts: 0, memory_bytes: null })));
        return;
      }
      const byId = new Map(parseSystemctlShow(String(stdout)).map((record) => [record.Id, serviceRecord(record)]));
      resolve(units.map((unit) => byId.get(unit) || byId.get(`${unit}.service`) || {
        unit, active: 'unknown', sub: '', result: '', since: null, restarts: 0, memory_bytes: null,
      }));
    });
  });

  const readCertificates = () => {
    let names = [];
    try {
      names = fs.readdirSync(certDirectory, { withFileTypes: true }).filter((entry) => entry.isDirectory()).map((entry) => entry.name);
    } catch {
      return [];
    }
    return names.sort().map((name) => {
      try {
        const certificate = new crypto.X509Certificate(fs.readFileSync(path.join(certDirectory, name, 'cert.pem')));
        const notAfter = new Date(certificate.validTo);
        return {
          name,
          not_after: notAfter.toISOString(),
          days_left: Math.floor((notAfter.getTime() - now()) / 86_400_000),
        };
      } catch {
        return { name, not_after: null, days_left: null };
      }
    });
  };

  const readDisk = () => {
    try {
      const stats = fs.statfsSync(diskPath);
      const total = stats.blocks * stats.bsize;
      const available = stats.bavail * stats.bsize;
      return { path: diskPath, total_bytes: total, used_bytes: total - stats.bfree * stats.bsize, available_bytes: available };
    } catch {
      return { path: diskPath, total_bytes: null, used_bytes: null, available_bytes: null };
    }
  };

  const readBackup = () => {
    try {
      const status = JSON.parse(fs.readFileSync(backupStatusPath, 'utf8'));
      return {
        last_run_at: status.last_run_at ?? null,
        last_result: status.last_result ?? null,
        last_success_at: status.last_success_at ?? null,
        last_commit: status.last_commit ?? null,
        last_archive_bytes: status.last_archive_bytes ?? null,
        message: typeof status.message === 'string' ? status.message.slice(0, 200) : null,
      };
    } catch {
      return null;
    }
  };

  const releaseVersion = (link, pattern) => {
    if (!link) return null;
    try {
      const target = fs.readlinkSync(link);
      return target.match(pattern)?.[1] ?? null;
    } catch {
      return null;
    }
  };

  const collect = async () => {
    const [loadOne, loadFive, loadFifteen] = os.loadavg();
    let memory = { total_bytes: null, available_bytes: null, swap_total_bytes: null, swap_used_bytes: null };
    try {
      memory = parseMeminfo(fs.readFileSync('/proc/meminfo', 'utf8'));
    } catch {
      // Not Linux (tests, local dev): leave nulls.
    }
    const services = await readServices();
    return {
      generated_at: new Date(now()).toISOString(),
      host: {
        hostname: os.hostname(),
        kernel: os.release(),
        uptime_seconds: Math.round(os.uptime()),
        cpu_count: os.cpus().length,
        load: [loadOne, loadFive, loadFifteen].map((value) => Math.round(value * 100) / 100),
      },
      memory,
      disk: readDisk(),
      services,
      certificates: readCertificates(),
      backup: readBackup(),
      versions: {
        engine: engineVersion || releaseVersion(engineBinaryLink, /engine\/(v[^/]+)\//),
        panel: panelVersion || releaseVersion(panelBinaryLink, /manager-plus\/(v[^/]+)\//),
      },
      summary: {
        services_total: services.length,
        services_down: services.filter((service) => service.active !== 'active').map((service) => service.unit),
      },
    };
  };

  return {
    async getStatus() {
      if (cached && now() - cached.at < cacheMs) return cached.value;
      if (!inFlight) {
        inFlight = collect()
          .then((value) => {
            cached = { at: now(), value };
            return value;
          })
          .finally(() => {
            inFlight = null;
          });
      }
      return inFlight;
    },
  };
}

export const _internal = { parseSystemctlShow, parseMeminfo, serviceRecord };
