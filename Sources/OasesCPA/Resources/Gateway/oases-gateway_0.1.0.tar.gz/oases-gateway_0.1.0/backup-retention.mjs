// Retention for the policy backups.
//
// Before every policy save the gateway copies the live permissions.json into the policy backup
// directory (POLICY_BACKUP_DIR) as permissions-<stamp>-<uuid>.json. Left alone, that directory
// grows for as long as the gateway runs; POLICY_BACKUP_KEEP (default 100) caps it, and
// savePermissions in server.mjs calls prunePolicyBackups once the new policy is in place.
//
// Which backups are the newest is decided by file name, not by modification time: the stamp is
// `new Date().toISOString()` with ":" and "." turned into "-" (2026-11-07T12-34-56-789Z), which is
// UTC and fixed width, so the names sort in time order to the millisecond. Two backups of the same
// millisecond (two gateway workers saving at once) are ordered by their random uuid, which is
// arbitrary but harmless: both are of the same moment.
//
// Pruning is housekeeping and must never get in the way of a save. prunePolicyBackups does not
// throw, whatever the directory, the file system or the arguments look like; it logs a warning
// and returns how many backups it did remove.
import fs from 'fs';
import path from 'path';

export const DEFAULT_POLICY_BACKUP_KEEP = 100;

// The only files this module ever looks at (and so the only ones it may remove).
const BACKUP_NAME = /^permissions-.*\.json$/;
// A plain decimal whole number of at least 1: no sign, no padding, no leading zero, no exponent.
const WHOLE_NUMBER = /^[1-9][0-9]*$/;

/**
 * How many backups to keep, from POLICY_BACKUP_KEEP in `env`. Anything that is not a plain
 * decimal whole number of at least 1 ("0", "abc", "2.5", "", "-1", "1e2", " 3 ", ...) means
 * the default: a limit that is misread must never delete more history than the default would,
 * which is also why a value padded with spaces is not trimmed into a smaller limit.
 */
export function policyBackupKeep(env) {
  const text = String(env?.POLICY_BACKUP_KEEP ?? '');
  if (!WHOLE_NUMBER.test(text)) return DEFAULT_POLICY_BACKUP_KEEP;
  const keep = Number(text);
  return Number.isSafeInteger(keep) ? keep : DEFAULT_POLICY_BACKUP_KEEP;
}

/**
 * Keeps the newest `keep` (a whole number of at least 1) policy backups of `dir` and removes the
 * rest, oldest first. Returns the number of backups removed; never throws.
 *
 * Only regular files named permissions-*.json count: other files, directories and symbolic links
 * (whatever they are called) are left alone and do not count towards `keep`. A backup that
 * cannot be removed is reported once for the whole pass and the others are still removed; one
 * that is already gone (another worker pruned it first) is not an error.
 *
 * `fsImpl` needs readdirSync(dir, { withFileTypes: true }) and unlinkSync(file).
 */
export function prunePolicyBackups(dir, keep, fsImpl = fs) {
  let removed = 0;
  try {
    // keep < 1 would remove every backup, NaN or a fraction would remove an arbitrary number.
    if (!Number.isInteger(keep) || keep < 1) {
      console.warn(`[perms] Not pruning policy backups: the limit must be a whole number of at least 1, got ${String(keep)}`);
      return 0;
    }
    const names = fsImpl.readdirSync(dir, { withFileTypes: true })
      .filter((entry) => entry.isFile() && BACKUP_NAME.test(entry.name))
      .map((entry) => entry.name)
      .sort();
    let failures = 0;
    let firstFailure;
    for (const name of names.slice(0, Math.max(0, names.length - keep))) {
      try {
        fsImpl.unlinkSync(path.join(dir, name));
        removed += 1;
      } catch (error) {
        if (error?.code === 'ENOENT') continue;
        failures += 1;
        firstFailure ??= error;
      }
    }
    if (failures) {
      console.warn(`[perms] Could not remove ${failures} policy backup(s) over the limit: ${firstFailure?.message || firstFailure}`);
    }
  } catch (error) {
    console.warn(`[perms] Could not prune policy backups: ${error?.message || error}`);
  }
  return removed;
}
