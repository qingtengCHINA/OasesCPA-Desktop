// Request handling for model-pack keys (`sk-pk-…`).
//
// A pack key never reaches the engine's own key checks and is never forwarded:
// the gateway validates it here, swaps the public model id for a real member
// model, and calls the engine with one dedicated internal key. Anything that
// could reveal the real models or what is behind them (response headers, `model`
// fields, error text, /v1/models) is rewritten, rebuilt from allow-lists, or
// dropped on the way back. The upstream's own wording is never repeated.
//
// Failover (moving on to the next member) is only possible while nothing has
// been written to the client yet: connection errors, timeouts, bad statuses and
// unusable bodies on the way in, plus any failure while a non-streaming body is
// still being buffered. Once a stream has started it is never replayed.
//
// Every wait has a deadline and nothing awaits a cancel(): a stalled upstream or
// a client that stops reading cannot hold a request, a timer or memory forever.

import { createSseModelRewriter, estimateTokens, rewriteJsonText, safeError } from './pack-rewrite.mjs';
import { isCreditExhausted, isReasoningRejection, withIdentity, withoutReasoning } from './pack-identity.mjs';

const PROXIED_PATHS = new Set(['/v1/chat/completions', '/v1/responses', '/v1/messages']);
const SAFE_RESPONSE_HEADERS = ['content-type', 'cache-control', 'retry-after'];
const RELAYED_ERROR_STATUS = new Set([400, 402, 405, 409, 410, 413, 415, 422, 451]);
const DEFAULT_IDLE_TIMEOUT_MS = 120_000;
const DEFAULT_NON_STREAM_TIMEOUT_MS = 120_000;
const DEFAULT_MAX_BUFFERED_BYTES = 32 * 1024 * 1024;
const DEFAULT_MAX_FRAME_CHARS = 1024 * 1024;
const DEFAULT_ERROR_BODY_TIMEOUT_MS = 10_000;
const DEFAULT_BACKPRESSURE_TIMEOUT_MS = 60_000;
const ERROR_BODY_LIMIT = 64 * 1024;
const DEFAULT_MAX_CONCURRENT_PER_KEY = 8;
// An inline attachment (an image, a PDF) is a few thousand tokens however many bytes its base64 takes.
const DATA_URL = /data:[a-z0-9.+/-]{1,100};base64,[A-Za-z0-9+/=_-]{200,}/gi;
const ATTACHMENT_STAND_IN = 'x'.repeat(6000);
const CLIENT_CREDENTIAL_HEADERS = new Set(['authorization', 'x-api-key', 'x-goog-api-key', 'proxy-authorization', 'cookie']);
const CACHE_READ = /"cache_read_input_tokens"\s*:\s*(\d+)/g;
const CACHE_CREATION = /"cache_creation_input_tokens"\s*:\s*(\d+)/g;

const isPlainObject = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value);

// A promise we do not wait for: cancelling a body must never be able to stall a request.
function fire(promise) {
  try {
    Promise.resolve(promise).catch(() => {});
  } catch {
    /* already settled or not a promise */
  }
}

// Moving on to another member is right for these: the member (or its account)
// is the problem, not the request. 401/403/404 mean the internal key or the
// member model is misconfigured; they are logged loudly and never shown. A
// redirect is never followed or relayed.
const isMemberFailure = (status) => (
  status === 401 || status === 402 || status === 403 || status === 404 || status === 408 || status === 429 || status >= 500
  || (status >= 300 && status < 400)
);

// The engine answers a model it cannot route with a 400, not a 404.
const isUnroutableModel = (status, error) => (
  status === 400 && (error?.code === 'model_not_found' || /unknown provider for model/i.test(String(error?.message ?? '')))
);

function estimatePromptTokens(requestText) {
  return estimateTokens(String(requestText || '').replace(DATA_URL, ATTACHMENT_STAND_IN), { asciiPerToken: 4 });
}

const STATE_ERRORS = {
  disabled: [403, 'key_disabled', 'This API key is disabled.'],
  expired: [403, 'key_expired', 'This API key has expired.'],
  exhausted: [403, 'quota_exhausted', 'This API key has used up its quota.'],
};

// Native Anthropic usage reports cached input separately from `input_tokens`
// (OpenAI-style totals already include it), so /v1/messages needs them added.
function createCacheScanner() {
  const decoder = new TextDecoder();
  let tail = '';
  let read = 0;
  let creation = 0;
  const largest = (pattern, current, text) => {
    let max = current;
    for (const match of text.matchAll(pattern)) {
      const value = Number(match[1]);
      if (Number.isSafeInteger(value) && value > max) max = value;
    }
    return max;
  };
  return {
    add(bytes) {
      const text = tail + decoder.decode(bytes, { stream: true });
      read = largest(CACHE_READ, read, text);
      creation = largest(CACHE_CREATION, creation, text);
      tail = text.slice(-96); // enough to hold a key and its number split across chunks
    },
    total: () => read + creation,
  };
}

export function createPackProxy({
  packs,
  engineBaseUrl,
  engineKey,
  createUsageAccumulator,
  buildUpstreamHeaders,
  sendJSON,
  readJson,
  requestPathname,
  getApiKey,
  fetchImpl = fetch,
  logger = console,
  idleTimeoutMs = DEFAULT_IDLE_TIMEOUT_MS,
  nonStreamTimeoutMs = DEFAULT_NON_STREAM_TIMEOUT_MS,
  maxBufferedBytes = DEFAULT_MAX_BUFFERED_BYTES,
  maxFrameChars = DEFAULT_MAX_FRAME_CHARS,
  errorBodyTimeoutMs = DEFAULT_ERROR_BODY_TIMEOUT_MS,
  backpressureTimeoutMs = DEFAULT_BACKPRESSURE_TIMEOUT_MS,
  maxConcurrentPerKey = DEFAULT_MAX_CONCURRENT_PER_KEY,
  // owned_by of the pack model in /v1/models.
  brandOwner = 'oases',
}) {
  const inflight = new Map();
  const engineBase = String(engineBaseUrl || '').replace(/\/+$/, '');

  const errorBody = (code, message, type) => ({ error: { message, type, code } });

  async function readLimited(response, limit) {
    const reader = response.body?.getReader();
    if (!reader) return '';
    const chunks = [];
    let total = 0;
    try {
      while (total < limit) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(Buffer.from(value));
        total += value.length;
      }
    } catch {
      /* an aborted or broken error body is just a short one */
    } finally {
      fire(reader.cancel());
    }
    return Buffer.concat(chunks).toString('utf8');
  }

  // True once the data is on its way; false when the client closed or stopped
  // reading for longer than the deadline.
  function writeWithBackpressure(res, data) {
    if (res.destroyed || res.writableEnded) return Promise.resolve(false);
    if (res.write(data)) return Promise.resolve(true);
    return new Promise((resolve) => {
      const finish = (value) => {
        clearTimeout(deadline);
        res.off('drain', onDrain);
        res.off('close', onClose);
        res.off('error', onClose);
        resolve(value);
      };
      const onDrain = () => finish(true);
      const onClose = () => finish(false);
      const deadline = setTimeout(() => finish(false), backpressureTimeoutMs);
      res.once('drain', onDrain);
      res.once('close', onClose);
      res.once('error', onClose);
    });
  }

  function prepareBody(body, member, pathname, wantsStream, pack) {
    // Every member introduces itself as the pack's public name unless the pack turned that off (pack-identity.mjs).
    const source = pack && pack.identity !== false ? withIdentity(body, pathname, pack.model_id) : body;
    const upstream = { ...source, model: member.model };
    // Billing needs the upstream's own token counts, so streamed chat
    // completions are always asked to report usage.
    if (wantsStream && pathname === '/v1/chat/completions') {
      upstream.stream_options = { ...(isPlainObject(body.stream_options) ? body.stream_options : {}), include_usage: true };
    }
    return JSON.stringify(upstream);
  }

  // The engine must only ever see the internal key: nothing the client sent that
  // could carry a credential survives, whatever it is called.
  function engineHeaders(req, res, internalKey, payloadLength) {
    const headers = {};
    for (const [name, value] of Object.entries(buildUpstreamHeaders(req.headers, internalKey))) {
      if (!CLIENT_CREDENTIAL_HEADERS.has(name.toLowerCase())) headers[name] = value;
    }
    headers.Authorization = `Bearer ${internalKey}`;
    headers['Content-Type'] = 'application/json';
    const requestId = req.__requestId || res.getHeader('x-request-id');
    if (requestId) headers['X-Request-Id'] = String(requestId);
    void payloadLength;
    return headers;
  }

  function responseHeaders(response, isSse) {
    const out = {};
    for (const name of SAFE_RESPONSE_HEADERS) {
      const value = response.headers.get(name);
      if (value) out[name] = value;
    }
    if (isSse) {
      out['cache-control'] = out['cache-control'] || 'no-cache';
      out['x-accel-buffering'] = 'no';
    } else if (!out['content-type']) {
      out['content-type'] = 'application/json';
    }
    return out;
  }

  // What the request cost. The member's prices are the ones captured when the
  // request was scheduled, so editing the pack mid-flight cannot change them.
  function settle({ key, member, accumulator, cache, pathname, requestText, responseBytes, textTokens, isSse, completed }) {
    const total = accumulator.finish();
    const split = accumulator.breakdown();
    let prompt = split.prompt_tokens || 0;
    let completion = split.completion_tokens || 0;
    if (total > prompt + completion) completion += total - (prompt + completion);
    // Native Anthropic usage reports cached input ON TOP of `input_tokens`, but some routes
    // (Antigravity's message_start) already include it. The two cannot be told apart from
    // the numbers alone, so the cache is added only when input_tokens is smaller than it
    // (clearly the "on top" shape): the worst case is a little under-billing, never double billing.
    if (pathname === '/v1/messages' && cache) {
      const cached = cache.total();
      if (prompt < cached) prompt += cached;
    }

    // Usage that never arrived must not mean free calls. A stream's size on the wire says little
    // about its tokens (every frame carries JSON overhead), so its output is estimated from the
    // text it actually delivered (about three characters per token, leaning high).
    const estimatedPrompt = estimatePromptTokens(requestText);
    const estimatedCompletion = isSse ? textTokens : Math.ceil(responseBytes / 4);
    if (prompt + completion === 0 || accumulator.trusted() === false) {
      prompt = Math.max(prompt, estimatedPrompt);
      completion = Math.max(completion, estimatedCompletion);
    } else if (!completed) {
      // The stream ended before its final usage report: the first report only covers the start.
      completion = Math.max(completion, estimatedCompletion);
    }
    packs.recordUsage(key.id, {
      promptTokens: prompt,
      completionTokens: completion,
      memberModel: member.model,
      prices: { input_usd_per_1m: member.input_usd_per_1m, output_usd_per_1m: member.output_usd_per_1m },
    });
  }

  // What the engine said, parsed; it is only used to decide what to do and what allow-listed
  // fields to keep. The upstream's own words are never repeated to the client.
  async function readUpstreamError(response) {
    const text = await readLimited(response, ERROR_BODY_LIMIT);
    try {
      const parsed = JSON.parse(text);
      return isPlainObject(parsed?.error) ? parsed.error : parsed;
    } catch {
      return undefined;
    }
  }

  function interruptedFrame(pathname, timedOut) {
    const error = safeError({ code: timedOut ? 'stream_idle_timeout' : 'stream_interrupted' }, { fallbackType: timedOut ? 'timeout_error' : 'upstream_error' });
    if (pathname === '/v1/messages') {
      return `event: error\ndata: ${JSON.stringify({ type: 'error', error: { type: 'api_error', message: error.message, code: error.code } })}\n\n`;
    }
    if (pathname === '/v1/responses') {
      return `event: error\ndata: ${JSON.stringify({ type: 'error', code: error.code, message: error.message })}\n\n`;
    }
    return `data: ${JSON.stringify({ error })}\n\n`;
  }

  // One upstream attempt. Resolves { done: true } once the client has been
  // answered (success, a relayed client error, or a gone client), or
  // { done: false, timedOut } when the next member should be tried.
  async function attempt({ req, res, key, pack, member, pathname, body, wantsStream, timeoutMs, state, internalKey, withoutThinking = false }) {
    const controller = new AbortController();
    state.controller = controller;
    let timedOut = false;
    let timer = null;
    const arm = (ms) => {
      clearTimeout(timer);
      timer = setTimeout(() => { timedOut = true; controller.abort(); }, ms);
    };
    const stop = () => { clearTimeout(timer); timer = null; };
    // Gives up on this attempt: aborting frees the socket without waiting for any cancel().
    const release = () => {
      stop();
      try { controller.abort(); } catch { /* already aborted */ }
    };
    arm(timeoutMs);

    const payload = prepareBody(body, member, pathname, wantsStream, pack);
    const headers = engineHeaders(req, res, internalKey, payload.length);

    let response;
    try {
      response = await fetchImpl(`${engineBase}${pathname}`, { method: 'POST', headers, body: payload, signal: controller.signal, redirect: 'manual' });
    } catch (error) {
      release();
      if (state.clientGone) return { done: true };
      logger.warn?.(`[packs] ${member.model}: connection failed (${timedOut ? 'timeout' : error.message})`);
      return { done: false, timedOut };
    }

    if (isMemberFailure(response.status)) {
      release();
      fire(response.body?.cancel?.());
      logger.warn?.(`[packs] ${member.model}: upstream ${response.status}${response.status === 401 || response.status === 403 ? ' (check the internal engine key)' : ''}`);
      return { done: false, timedOut: false };
    }
    if (!response.ok) {
      arm(errorBodyTimeoutMs);
      const error = await readUpstreamError(response);
      stop();
      if (isCreditExhausted(response.status, error)) {
        // The upstream account behind this member is out of credit: the caller has done nothing wrong, so the pack
        // moves on to the next member. The provider's wording stays in the log of the engine, not in the answer.
        release();
        logger.warn?.(`[packs] ${member.model}: the upstream account is out of credit, moving to the next member`);
        return { done: false, timedOut: false };
      }
      if (!withoutThinking && isReasoningRejection(response.status, error)) {
        // The member refused the thinking level (models differ on which levels they take). The level is a hint,
        // not a requirement: ask the same member again without it before giving the call up.
        const stripped = withoutReasoning(body);
        if (stripped) {
          release();
          logger.warn?.(`[packs] ${member.model}: rejected the thinking setting, retrying without it`);
          return attempt({ req, res, key, pack, member, pathname, body: stripped, wantsStream, timeoutMs, state, internalKey, withoutThinking: true });
        }
      }
      if (isUnroutableModel(response.status, error)) {
        // The member's model is not registered in the engine: that is the pack's problem, not the caller's.
        release();
        logger.warn?.(`[packs] ${member.model}: the engine cannot route this model (check the member name)`);
        return { done: false, timedOut: false };
      }
      const status = RELAYED_ERROR_STATUS.has(response.status) ? response.status : 400;
      sendJSON(res, status, { error: safeError(error, { status }) });
      return { done: true };
    }

    const isSse = /text\/event-stream/i.test(response.headers.get('content-type') || '');
    const reader = response.body?.getReader();
    if (!reader) {
      release();
      return { done: false, timedOut: false };
    }
    const accumulator = createUsageAccumulator();
    const cache = pathname === '/v1/messages' ? createCacheScanner() : null;
    let responseBytes = 0;

    let first;
    try {
      first = await reader.read();
    } catch {
      release();
      if (state.clientGone) return { done: true };
      return { done: false, timedOut };
    }
    if (first.done) {
      release();
      logger.warn?.(`[packs] ${member.model}: empty response`);
      return { done: false, timedOut: false };
    }

    if (isSse) {
      // Committed: from here on the client owns the stream.
      stop();
      arm(idleTimeoutMs);
      res.writeHead(response.status, responseHeaders(response, true));
      const rewriter = createSseModelRewriter(pack.model_id, { maxFrameChars });
      let completed = false;
      const relay = async (value) => {
        responseBytes += value.length;
        accumulator.add(value);
        cache?.add(value);
        const out = rewriter.push(value);
        if (out && !(await writeWithBackpressure(res, out))) {
          state.clientGone = true;
          try { res.destroy(); } catch { /* already closed */ }
          throw new Error('the client stopped reading');
        }
      };
      try {
        await relay(first.value);
        for (;;) {
          if (state.clientGone) { fire(reader.cancel()); break; }
          const { done, value } = await reader.read();
          if (done) { completed = true; break; }
          arm(idleTimeoutMs);
          await relay(value);
        }
        if (completed && !state.clientGone) {
          const tail = rewriter.flush();
          if (tail) res.write(tail);
        }
        stop();
        if (!res.writableEnded) res.end();
      } catch {
        release();
        fire(reader.cancel());
        if (!state.clientGone && !res.writableEnded) {
          try { res.write(interruptedFrame(pathname, timedOut)); } catch { /* client gone */ }
          try { res.end(); } catch { /* client gone */ }
        }
      } finally {
        // A clean close is not enough: a stream that never delivered its final usage report was cut short.
        settle({ key, member, accumulator, cache, pathname, requestText: payload, responseBytes, textTokens: rewriter.stats.textTokens, isSse: true, completed: completed && !state.clientGone && rewriter.stats.finalUsage });
      }
      return { done: true };
    }

    // Not a stream: buffer the whole body first, so a failure while reading it
    // can still fall over to the next member without the client noticing.
    if (first.value.length > maxBufferedBytes) {
      release();
      fire(reader.cancel());
      logger.warn?.(`[packs] ${member.model}: response too large`);
      return { done: false, timedOut: false };
    }
    const chunks = [Buffer.from(first.value)];
    let buffered = first.value.length;
    accumulator.add(first.value);
    cache?.add(first.value);
    arm(nonStreamTimeoutMs);
    try {
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buffered += value.length;
        if (buffered > maxBufferedBytes) throw new Error('response too large');
        accumulator.add(value);
        cache?.add(value);
        chunks.push(Buffer.from(value));
      }
    } catch (error) {
      release();
      fire(reader.cancel());
      if (state.clientGone) return { done: true };
      logger.warn?.(`[packs] ${member.model}: body failed (${timedOut ? 'timeout' : error.message})`);
      return { done: false, timedOut };
    }
    stop();
    responseBytes = buffered;
    const rewritten = rewriteJsonText(Buffer.concat(chunks).toString('utf8'), pack.model_id);
    if (rewritten === null) {
      // A "successful" answer that is not a JSON object (an error page, a truncated body) is not relayed.
      logger.warn?.(`[packs] ${member.model}: answer was not a JSON object`);
      return { done: false, timedOut: false };
    }
    if (!state.clientGone) {
      res.writeHead(response.status, responseHeaders(response, false));
      res.end(rewritten);
    }
    settle({ key, member, accumulator, cache, pathname, requestText: payload, responseBytes, textTokens: 0, isSse: false, completed: true });
    return { done: true };
  }

  async function dispatch(req, res, reqBody) {
    const drain = () => { if (reqBody === undefined) req.resume?.(); };
    const deny = (status, code, message, type = 'invalid_request_error') => {
      drain();
      sendJSON(res, status, errorBody(code, message, type));
    };

    const credentials = getApiKey(req.headers, req.url, req.rawHeaders);
    if (credentials.error) return deny(400, credentials.error, 'Conflicting or invalid API credentials.');
    if (!packs.available()) return deny(503, 'packs_unavailable', 'This service is temporarily unavailable.', 'server_error');
    const resolved = packs.resolveKey(credentials.apiKey);
    if (!resolved) return deny(401, 'invalid_api_key', 'Invalid API key.');
    const { key, pack } = resolved;
    const pathname = requestPathname(req.url);

    if (req.method === 'GET' && pathname === '/v1/key') {
      const view = packs.statusView(key, pack);
      sendJSON(res, 200, {
        data: {
          label: key.label || '',
          status: view.status,
          expires_at: view.expires_at,
          model: pack.model_id,
          limits: { total_tokens: key.limits.total_tokens ?? null, total_cost_usd: key.limits.total_cost_usd ?? null },
          usage: { tokens: view.tokens.used, cost_usd: view.cost_usd.used, requests: key.usage.requests || 0, last_used_at: view.last_used_at },
          // Usage and limits above are this period's; when the quota is restored on a schedule, this says when it comes back.
          resets_at: view.resets_at,
          reset_every: view.reset_every,
        },
      });
      return undefined;
    }

    const isModels = req.method === 'GET' && pathname === '/v1/models';
    const isProxied = req.method === 'POST' && PROXIED_PATHS.has(pathname);
    if (!isModels && !isProxied) return deny(404, 'not_found', 'Not found.');

    const status = packs.keyState(key, pack);
    if (status !== 'active') {
      const [code, errorCode, message] = STATE_ERRORS[status];
      return deny(code, errorCode, message, 'permission_error');
    }

    if (isModels) {
      sendJSON(res, 200, {
        object: 'list',
        data: [{ id: pack.model_id, object: 'model', created: Math.floor(new Date(pack.created_at).getTime() / 1000) || 0, owned_by: brandOwner }],
      });
      return undefined;
    }

    // Read once and keep: the key file can disappear between attempts, and an empty key
    // must never end up making the pack key itself the credential sent to the engine.
    const internalKey = engineKey();
    if (typeof internalKey !== 'string' || !internalKey) {
      logger.error?.('[packs] the internal engine key is not configured');
      return deny(503, 'packs_unavailable', 'This service is temporarily unavailable.', 'server_error');
    }

    const body = reqBody !== undefined ? reqBody : await readJson(req);
    if (body && body.__bodyTooLarge) return deny(413, 'payload_too_large', 'Request body too large.');
    if (!isPlainObject(body)) return deny(400, 'invalid_request', 'Invalid request body.');
    if (typeof body.model !== 'string' || body.model.trim().toLowerCase() !== pack.model_id.trim().toLowerCase()) {
      return deny(404, 'model_not_found', 'The model does not exist or you do not have access to it.');
    }

    const wantsStream = body.stream === true;
    const timeoutMs = wantsStream ? pack.failover.first_byte_timeout_ms : nonStreamTimeoutMs;
    const order = packs.memberOrder(pack).slice(0, pack.failover.max_attempts);
    const state = { controller: null, clientGone: false };
    res.once('close', () => {
      if (res.writableFinished) return;
      state.clientGone = true;
      try { state.controller?.abort(); } catch { /* ignore */ }
    });

    // A key may have only so many requests running at once: usage is settled when a request ends,
    // so without a bound any number of parallel requests could overshoot the quota together.
    const running = inflight.get(key.id) || 0;
    if (running >= maxConcurrentPerKey) {
      res.setHeader('Retry-After', '1');
      return deny(429, 'too_many_concurrent_requests', 'Too many requests are running for this API key. Please retry shortly.', 'rate_limit_error');
    }
    inflight.set(key.id, running + 1);
    let attempts = 0;
    let timeouts = 0;
    try {
      for (const member of order) {
        if (state.clientGone) return undefined;
        attempts += 1;
        const outcome = await attempt({ req, res, key, pack, member, pathname, body, wantsStream, timeoutMs, state, internalKey });
        if (outcome.done) return undefined;
        if (outcome.timedOut) timeouts += 1;
      }
    } finally {
      const left = (inflight.get(key.id) || 1) - 1;
      if (left > 0) inflight.set(key.id, left);
      else inflight.delete(key.id);
    }
    if (state.clientGone) return undefined;
    if (attempts > 0 && timeouts === attempts) {
      return deny(504, 'pack_timeout', 'The model did not respond in time. Please retry.', 'timeout_error');
    }
    return deny(502, 'pack_unavailable', 'The model is temporarily unavailable. Please retry.', 'upstream_error');
  }

  async function handle(req, res, reqBody) {
    try {
      await dispatch(req, res, reqBody);
    } catch (error) {
      logger.error?.(`[packs] unexpected error: ${error.stack || error.message}`);
      if (!res.headersSent) {
        try { sendJSON(res, 500, errorBody('internal_error', 'Internal error.', 'server_error')); } catch { /* ignore */ }
      } else {
        try { res.end(); } catch { /* ignore */ }
      }
    }
  }

  return { handle };
}
