// Compatibility helpers for upstreams that are stricter or stranger than the OpenAI
// chat API. Written for Mistral (Vibe key, api.mistral.ai) but nothing here is tied
// to a host name: every rule is keyed on what the upstream actually says or sends.
//
// Request side (repairChatRequest): Mistral validates the body strictly. It answers 422
// `extra_forbidden` to fields OpenAI clients routinely send (`user`, `store`, `effort`,
// `reasoning_content` inside assistant history), 422 to the `developer` role, and 400 to
// a `reasoning_effort` the model does not offer. The error says exactly what to change,
// so the gateway applies that change and resends once instead of failing the client.
//
// Response side: Mistral's thinking models (zai-glm-5-3, zai-glm-5-3-flash) return
// `content` as an array of typed chunks, [{type:"thinking",…},{type:"text",…}], in both
// the JSON body and every SSE delta. OpenAI clients expect a string, with the reasoning
// in `reasoning_content`. normalizeChatCompletionJson and createChatStreamNormalizer
// convert that shape and leave every standard response byte-for-byte untouched.

const PROTECTED_TOP_LEVEL = new Set(['model', 'messages', 'stream']);
const PROTECTED_MESSAGE_FIELDS = new Set(['role', 'content', 'tool_calls', 'tool_call_id']);
const LEVEL_ORDER = ['none', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'];
const ARRAY_CONTENT = /"content"\s*:\s*\[/;

function parseJson(text) {
  try { return JSON.parse(text); } catch { return null; }
}

const isObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
const hasOwn = (object, key) => Object.prototype.hasOwnProperty.call(object, key);

function validationDetails(parsed) {
  const detail = parsed?.message?.detail ?? parsed?.detail ?? parsed?.error?.detail;
  return Array.isArray(detail) ? detail : [];
}

// `loc` is FastAPI-style: ['body', 'messages', 1, 'assistant', 'reasoning_content'].
// Strings that name a union variant ("assistant") are not keys of the object, so a
// string segment that does not exist is skipped rather than treated as a failure.
function removeAtLoc(body, loc) {
  if (!Array.isArray(loc) || loc[0] !== 'body' || loc.length < 2) return false;
  const path = loc.slice(1);
  const last = path[path.length - 1];
  if (typeof last !== 'string') return false;
  if (path.length === 1 && PROTECTED_TOP_LEVEL.has(last)) return false;
  let current = body;
  let parentIsMessage = false;
  for (let i = 0; i < path.length - 1; i += 1) {
    const segment = path[i];
    if (Array.isArray(current) && Number.isInteger(segment)) {
      parentIsMessage = path[i - 1] === 'messages';
      current = current[segment];
    } else if (isObject(current) && hasOwn(current, segment)) {
      parentIsMessage = false;
      current = current[segment];
    } else if (isObject(current) && typeof segment === 'string') {
      continue; // union variant tag
    } else {
      return false;
    }
    if (current === null || typeof current !== 'object') return false;
  }
  if (!isObject(current) || !hasOwn(current, last)) return false;
  if (parentIsMessage && PROTECTED_MESSAGE_FIELDS.has(last)) return false;
  delete current[last];
  return true;
}

function errorMessageText(errorText, parsed) {
  if (typeof parsed?.error?.message === 'string') return parsed.error.message;
  if (typeof parsed?.message === 'string') return parsed.message;
  return String(errorText || '');
}

function nearestSupportedLevel(requested, supported) {
  const wanted = LEVEL_ORDER.indexOf(requested);
  const known = supported
    .map((name) => ({ name, rank: LEVEL_ORDER.indexOf(name) }))
    .filter((entry) => entry.rank >= 0)
    .sort((a, b) => a.rank - b.rank);
  if (wanted < 0 || known.length === 0) return null;
  const upward = known.find((entry) => entry.rank >= wanted);
  return (upward || known[known.length - 1]).name;
}

/**
 * Apply the change an upstream validation error asks for to the request body, in place.
 * Returns a list of what was changed; an empty list means nothing could be repaired and
 * the caller should forward the upstream error as it is.
 */
export function repairChatRequest(body, status, errorText) {
  const fixes = [];
  if (!isObject(body)) return fixes;
  const parsed = parseJson(errorText);

  if (status === 422 && parsed) {
    for (const item of validationDetails(parsed)) {
      if (!item || typeof item !== 'object') continue;
      if (item.type === 'extra_forbidden') {
        if (removeAtLoc(body, item.loc)) fixes.push(`removed ${item.loc.slice(1).join('.')}`);
      } else if (item.type === 'union_tag_invalid' && item.input?.role === 'developer') {
        const index = Array.isArray(item.loc) ? item.loc[2] : undefined;
        const message = Array.isArray(body.messages) ? body.messages[index] : undefined;
        if (isObject(message) && message.role === 'developer') {
          message.role = 'system';
          fixes.push(`messages.${index}.role developer -> system`);
        }
      }
    }
    return fixes;
  }

  if (status === 400 && typeof body.reasoning_effort === 'string') {
    const text = errorMessageText(errorText, parsed);
    const listed = /(?:valid levels|supported values)\s*:\s*\[?([^\]\n]*)\]?/i.exec(text);
    if (!listed) return fixes;
    const supported = listed[1].split(/[\s,'"]+/).filter(Boolean).map((name) => name.toLowerCase());
    const requested = body.reasoning_effort.toLowerCase();
    if (supported.includes(requested)) return fixes;
    const replacement = nearestSupportedLevel(requested, supported);
    if (replacement) {
      fixes.push(`reasoning_effort ${body.reasoning_effort} -> ${replacement}`);
      body.reasoning_effort = replacement;
    }
  }
  return fixes;
}

function thinkingText(thinking) {
  if (typeof thinking === 'string') return thinking;
  if (!Array.isArray(thinking)) return '';
  let out = '';
  for (const part of thinking) {
    if (typeof part === 'string') out += part;
    else if (part && part.type === 'text' && typeof part.text === 'string') out += part.text;
  }
  return out;
}

function flattenChunks(chunks) {
  let text = '';
  let reasoning = '';
  for (const chunk of chunks) {
    if (typeof chunk === 'string') text += chunk;
    else if (chunk && chunk.type === 'text' && typeof chunk.text === 'string') text += chunk.text;
    else if (chunk && chunk.type === 'thinking') reasoning += thinkingText(chunk.thinking);
  }
  return { text, reasoning };
}

function convertMessageLike(target) {
  if (!target || !Array.isArray(target.content)) return false;
  const { text, reasoning } = flattenChunks(target.content);
  const hasToolCalls = Array.isArray(target.tool_calls) && target.tool_calls.length > 0;
  target.content = text === '' && hasToolCalls ? null : text;
  if (reasoning) target.reasoning_content = reasoning;
  return true;
}

/** Convert a non-streaming chat completion body. Returns the input text when nothing changes. */
export function normalizeChatCompletionJson(text) {
  if (typeof text !== 'string' || !ARRAY_CONTENT.test(text)) return text;
  const data = parseJson(text);
  if (!isObject(data) || !Array.isArray(data.choices)) return text;
  let changed = false;
  for (const choice of data.choices) {
    if (choice && convertMessageLike(choice.message)) changed = true;
  }
  return changed ? JSON.stringify(data) : text;
}

function convertFrame(frame) {
  if (!ARRAY_CONTENT.test(frame)) return frame;
  const eol = frame.includes('\r\n') ? '\r\n' : '\n';
  let changed = false;
  const lines = frame.split(eol).map((line) => {
    const match = /^data:[ \t]?([\s\S]*)$/.exec(line);
    if (!match) return line;
    const payload = parseJson(match[1]);
    if (!isObject(payload) || !Array.isArray(payload.choices)) return line;
    let touched = false;
    for (const choice of payload.choices) {
      if (choice && convertMessageLike(choice.delta)) touched = true;
    }
    if (!touched) return line;
    changed = true;
    return `data: ${JSON.stringify(payload)}`;
  });
  return changed ? lines.join(eol) : frame;
}

/**
 * Frame-aware SSE converter. push() takes upstream bytes and returns the text to send to
 * the client (possibly empty while a frame is incomplete); flush() returns what is left.
 */
export function createChatStreamNormalizer({ maxPendingChars = 1 << 20 } = {}) {
  const decoder = new TextDecoder('utf-8');
  const boundary = /\r?\n\r?\n/;
  let pending = '';
  return {
    push(chunk) {
      pending += decoder.decode(chunk, { stream: true });
      let out = '';
      for (;;) {
        const match = boundary.exec(pending);
        if (!match) break;
        out += convertFrame(pending.slice(0, match.index)) + match[0];
        pending = pending.slice(match.index + match[0].length);
      }
      if (pending.length > maxPendingChars) {
        out += pending;
        pending = '';
      }
      return out;
    },
    flush() {
      const rest = pending + decoder.decode();
      pending = '';
      return convertFrame(rest);
    },
  };
}
