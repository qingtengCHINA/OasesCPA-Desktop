// First-run setup of the gateway's data directory and its secrets.
//
//   node gateway/bootstrap.mjs [--data-dir <dir>] [--secrets-dir <dir>]
//
//   --data-dir     default: OASES_DATA_DIR, else ./data (the gateway's own rule, see paths.mjs)
//   --secrets-dir  default: <data-dir>/secrets
//
// It is safe to run again: it creates what is missing (and replaces an empty key file) and does
// not change a byte, a mode or a timestamp of anything else. Only the layout under these two
// directories is handled; the per-file path variables of the gateway are not read here.
//
// Exit status: 0 done, 2 the management key is missing or empty, 3 a path or permission problem
// (a wrong argument counts as one). stdout is exactly one line of JSON, the summary:
//   {"ok":true,"exit_code":0,"data_dir":…,"secrets_dir":…,"created":[…],"kept":[…],"warnings":[…]}
//   {"ok":false,"exit_code":2|3,"error":…,"path":…}
// `created` and `kept` hold names relative to the directory they live in (permissions.json,
// pack-engine-key, pack-store-key). `warnings` lists a secret file that group or other users can
// access: the management key, and a pack key that was kept as it was (one bootstrap creates is
// private). On failure stderr gets one human-readable line. No key material, the management key
// included, is ever printed.
//
// Steps, in this order. The first failure ends the run; nothing is rolled back, and running again
// carries on from there.
//   1. The arguments; anything unknown is a usage error.
//   2. <secrets-dir>/cpa-management-key must exist and not be blank. The installer creates that file,
//      bootstrap never does. A missing or blank key, and a secrets directory that does not exist,
//      end the run with status 2 before anything has been created. A secrets directory that
//      exists but is not private ends it with status 3.
//   3. The data directory, with any missing parents, mode 0700. An existing one must be private.
//   4. permissions.json, an empty version-2 policy, mode 0600, only if it does not exist.
//   5. backups/permissions, mode 0700.
//   6. pack-engine-key: the internal key that stands in for model-pack keys towards the engine.
//   7. pack-store-key. It is generated because the installer layout lists it, but this edition has
//      no cipher and the gateway does not read it: it is reserved and unused here.
// A private directory is one that is not a symlink, that group and other cannot write to, and that
// belongs to the current user or root. That is the gateway's rule (ensurePrivateDirectory in
// server.mjs), applied here the same way: an existing directory is checked and never chmod-ed.
// When parents have to be created, the nearest existing ancestor must be private too, so a data
// directory that would be created directly inside a world-writable directory such as /tmp is
// refused (status 3, nothing created), exactly as the gateway would refuse to create it.
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { DATA_FILES, resolveGatewayPaths } from './paths.mjs';

const tableRow = (key) => {
  const found = DATA_FILES.find((entry) => entry.key === key);
  if (!found) throw new Error(`paths.mjs has no ${key} row`);
  return found;
};
const MANAGEMENT_KEY = tableRow('keyFilePath');
const PERMISSIONS = tableRow('permissionsPath');
const POLICY_BACKUPS = tableRow('policyBackupDir');
const ENGINE_KEY = tableRow('packEngineKeyPath');
const STORE_KEY = tableRow('packStoreKeyFile');

// The table gives the layout under the data directory; the secrets live in --secrets-dir, so only
// the last path segment of a secret's row is used for them.
const nameInSecretsDir = (entry) => path.posix.basename(entry.relative);
const DEFAULT_SECRETS_SUBDIR = path.posix.dirname(MANAGEMENT_KEY.relative);

const PRIVATE_DIRECTORY = 0o700;
const PRIVATE_FILE = 0o600;
const INITIAL_PERMISSIONS = '{"schema_version":2,"keys":{}}\n';

const USAGE = 'usage: node bootstrap.mjs [--data-dir <dir>] [--secrets-dir <dir>]';
const USAGE_RESULT = { exitCode: 3, summary: { ok: false, exit_code: 3, error: 'usage', path: null } };

/**
 * Reads the command line (without node and the script). `env` and `cwd` decide the default data
 * directory exactly as the gateway does; relative paths are resolved against `cwd`. Returns
 * { dataDir, secretsDir }, both absolute, or { error: 'usage' }.
 */
export function parseBootstrapArgs(argv, env = process.env, cwd = process.cwd()) {
  const given = { '--data-dir': null, '--secrets-dir': null };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    const equals = arg.startsWith('--') ? arg.indexOf('=') : -1;
    const name = equals === -1 ? arg : arg.slice(0, equals);
    if (!Object.hasOwn(given, name) || given[name] !== null) return { error: 'usage' };
    let value;
    if (equals === -1) {
      i += 1;
      value = argv[i];
    } else {
      value = arg.slice(equals + 1);
    }
    // A value that starts with "--" is the next option: this one has no value.
    if (typeof value !== 'string' || value === '' || value.startsWith('--')) return { error: 'usage' };
    given[name] = value;
  }
  const dataDir = given['--data-dir'] === null
    ? resolveGatewayPaths(env, cwd).dataDir
    : path.resolve(cwd, given['--data-dir']);
  const secretsDir = given['--secrets-dir'] === null
    ? path.join(dataDir, DEFAULT_SECRETS_SUBDIR)
    : path.resolve(cwd, given['--secrets-dir']);
  return { dataDir, secretsDir };
}

// A failure with a place in the contract: the summary says which one and where.
class Failure extends Error {
  constructor(error, exitCode, target) {
    super(error);
    this.error = error;
    this.exitCode = exitCode;
    this.target = target;
  }
}
const refuse = (error, target, exitCode = 3) => new Failure(error, exitCode, target);

const lstatIfExists = (target) => {
  try {
    return fs.lstatSync(target);
  } catch (error) {
    if (error?.code === 'ENOENT') return null;
    throw error;
  }
};

const statIfExists = (target) => {
  try {
    return fs.statSync(target);
  } catch (error) {
    if (error?.code === 'ENOENT') return null;
    throw error;
  }
};

// `stat` must come from lstat, so that a symlink shows up as one.
function assertPrivateDirectory(stat, directory) {
  if (stat.isSymbolicLink()) throw refuse('insecure_directory', directory);
  if (!stat.isDirectory()) throw refuse('path_error', directory);
  if ((stat.mode & 0o022) !== 0) throw refuse('insecure_directory', directory);
  if (typeof process.getuid === 'function') {
    const uid = process.getuid();
    if (stat.uid !== uid && stat.uid !== 0) throw refuse('insecure_directory', directory);
  }
}

// Same walk as the gateway's: an existing directory is only checked, a missing one is created
// private (after its parent has been ensured) and checked again, so a directory that someone else
// slipped in between is caught too.
function ensurePrivateDirectory(directory) {
  const existing = lstatIfExists(directory);
  if (existing) {
    assertPrivateDirectory(existing, directory);
    return;
  }
  const parent = path.dirname(directory);
  if (parent === directory) throw refuse('insecure_directory', directory);
  ensurePrivateDirectory(parent);
  try {
    fs.mkdirSync(directory, { mode: PRIVATE_DIRECTORY });
  } catch (error) {
    if (error?.code !== 'EEXIST') throw error;
  }
  assertPrivateDirectory(fs.lstatSync(directory), directory);
}

/**
 * Creates `target` holding `content`, and never replaces anything: flag 'wx' is O_EXCL, which also
 * refuses a symlink that sits at the name. Returns false when the name is taken. The mode is set
 * on the open file, so it is exactly `mode` whatever the umask is. A file that could not be
 * written completely is removed again. `content` may be a function: it is called only once the
 * file exists, so a name that is taken costs no work (and no randomness).
 */
function createExclusive(target, content, mode) {
  let fd;
  try {
    fd = fs.openSync(target, 'wx', mode);
  } catch (error) {
    if (error?.code === 'EEXIST') return false;
    throw error;
  }
  let complete = false;
  try {
    fs.fchmodSync(fd, mode);
    fs.writeFileSync(fd, typeof content === 'function' ? content() : content);
    complete = true;
  } finally {
    fs.closeSync(fd);
    if (!complete) {
      try { fs.unlinkSync(target); } catch { /* the error being thrown is the one to report */ }
    }
  }
  return true;
}

// Swaps an empty file for a complete one in a single rename, so no reader ever sees half a key.
// Two bootstraps running at the same moment are not supported; the last rename would win.
// `content` is a string or a function, as for createExclusive.
function replaceThroughTemporaryFile(target, content, mode) {
  const temporary = path.join(path.dirname(target), `.${path.basename(target)}.${crypto.randomBytes(6).toString('hex')}.tmp`);
  if (!createExclusive(temporary, content, mode)) throw refuse('path_error', temporary);
  try {
    fs.renameSync(temporary, target);
  } catch (error) {
    try { fs.unlinkSync(temporary); } catch { /* the error being thrown is the one to report */ }
    throw error;
  }
}

// An existing name has to be a regular file, or a link that leads to one (secret volumes hand out
// files as links). A dangling link and everything else is refused.
function inspectExistingFile(target) {
  const own = fs.lstatSync(target);
  const resolved = own.isSymbolicLink() ? fs.statSync(target) : own;
  if (!resolved.isFile()) throw refuse('path_error', target);
  return { link: own.isSymbolicLink() };
}

const isBlank = (target) => fs.readFileSync(target, 'utf8').trim() === '';

// The warning for a secret file that group or other users can access (an empty list when it is
// private). `stat` is the file's own, followed through a link, as a secret volume provides it.
function looseModeWarnings(name, stat) {
  const mode = stat.mode & 0o777;
  if ((mode & 0o077) === 0) return [];
  return [`${name} is accessible to group or other users (mode ${mode.toString(8).padStart(4, '0')}); restrict it with chmod 600`];
}

// Step 2. Returns the warnings. The key file is read here only to see whether it holds anything.
function checkManagementKey(secretsDir) {
  const name = nameInSecretsDir(MANAGEMENT_KEY);
  const keyPath = path.join(secretsDir, name);
  const directory = lstatIfExists(secretsDir);
  if (directory) assertPrivateDirectory(directory, secretsDir);
  // stat, not lstat: a link to the key is as good as the key.
  const stat = directory ? statIfExists(keyPath) : null;
  if (!stat) throw refuse('management_key_missing', keyPath, 2);
  if (!stat.isFile()) throw refuse('path_error', keyPath);
  if (isBlank(keyPath)) throw refuse('management_key_empty', keyPath, 2);
  return looseModeWarnings(name, stat);
}

// Steps 4, 6 and 7. Returns 'created' or 'kept'.
function ensurePermissionsFile(target) {
  if (createExclusive(target, INITIAL_PERMISSIONS, PRIVATE_FILE)) return 'created';
  inspectExistingFile(target);
  return 'kept';
}

// `makeContent` generates the key; it only runs when the file is written, never for a kept one.
function ensureSecretFile(target, makeContent) {
  if (createExclusive(target, makeContent, PRIVATE_FILE)) return 'created';
  const { link } = inspectExistingFile(target);
  if (!isBlank(target)) return 'kept';
  // An empty link is not replaced by a file: that would cut the link, not fill the file.
  if (link) throw refuse('path_error', target);
  replaceThroughTemporaryFile(target, makeContent, PRIVATE_FILE);
  return 'created';
}

const newEngineKey = () => `oases-int-${crypto.randomBytes(32).toString('base64url')}\n`;
const newStoreKey = () => `${crypto.randomBytes(32).toString('base64')}\n`;

// A failure of the file system is a path problem. Anything else is a bug and is left to crash.
const isFileSystemError = (error) => typeof error?.code === 'string' && /^(E[A-Z0-9]+|ERR_FS_[A-Z_]+)$/.test(error.code);

/**
 * Runs the steps above on `dataDir` and `secretsDir` (resolved against the working directory when
 * relative) and returns { exitCode, summary } without printing anything.
 */
export function runBootstrap({ dataDir, secretsDir }) {
  const data = path.resolve(dataDir);
  const secrets = path.resolve(secretsDir);
  try {
    const warnings = checkManagementKey(secrets);
    ensurePrivateDirectory(data);

    const created = [];
    const kept = [];
    const record = (name, outcome) => (outcome === 'created' ? created : kept).push(name);
    record(PERMISSIONS.relative, ensurePermissionsFile(path.join(data, PERMISSIONS.relative)));
    ensurePrivateDirectory(path.join(data, POLICY_BACKUPS.relative));
    // A pack key that was already there is kept as it is, mode included; say when it is not private.
    for (const [entry, makeContent] of [[ENGINE_KEY, newEngineKey], [STORE_KEY, newStoreKey]]) {
      const name = nameInSecretsDir(entry);
      const target = path.join(secrets, name);
      const outcome = ensureSecretFile(target, makeContent);
      record(name, outcome);
      if (outcome === 'kept') warnings.push(...looseModeWarnings(name, fs.statSync(target)));
    }

    return { exitCode: 0, summary: { ok: true, exit_code: 0, data_dir: data, secrets_dir: secrets, created, kept, warnings } };
  } catch (error) {
    if (error instanceof Failure) {
      return { exitCode: error.exitCode, summary: { ok: false, exit_code: error.exitCode, error: error.error, path: error.target } };
    }
    if (isFileSystemError(error)) {
      const where = typeof error.path === 'string' ? error.path : data;
      return { exitCode: 3, summary: { ok: false, exit_code: 3, error: 'path_error', path: where } };
    }
    throw error;
  }
}

// True when this file is the one node was started with (compared by real path, so that a symlink
// to it counts), and false when it is imported or `node -e` is used.
function isEntryPoint() {
  const entry = process.argv[1];
  if (!entry) return false;
  try {
    return fs.realpathSync(entry) === fs.realpathSync(fileURLToPath(import.meta.url));
  } catch {
    return false;
  }
}

function main() {
  const parsed = parseBootstrapArgs(process.argv.slice(2), process.env, process.cwd());
  const { exitCode, summary } = parsed.error ? USAGE_RESULT : runBootstrap(parsed);
  process.stdout.write(`${JSON.stringify(summary)}\n`);
  if (!summary.ok) process.stderr.write(parsed.error ? `${USAGE}\n` : `bootstrap: ${summary.error}: ${summary.path}\n`);
  // exitCode, not exit(): the line above is written out before the process ends.
  process.exitCode = exitCode;
}

if (isEntryPoint()) main();
