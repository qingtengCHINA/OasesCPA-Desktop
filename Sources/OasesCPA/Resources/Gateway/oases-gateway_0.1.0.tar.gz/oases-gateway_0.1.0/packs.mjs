// Model packs: store, keys, limits, scheduling and account binding.
//
// A pack bundles several real models behind one public model id. Pack keys
// (`sk-pk-…`) are independent of the engine's api-keys and of permissions.json:
// only a SHA-256 hash and the last four characters are stored, and the plaintext
// is returned exactly once, by createKeys().
//
// State lives in memory and is written to one JSON file:
//   * Admin changes and account bindings are written before they are
//     acknowledged (persistDurably); if the write fails the caller gets an
//     error instead of a promise that would vanish on restart.
//   * Usage is written debounced and retried until it lands. If writes keep
//     failing for PERSIST_FAIL_GRACE_MS the service reports itself unavailable,
//     so pack keys stop being served rather than run on state that cannot be saved.
//   * A store that cannot be read, or whose contents fail strict validation, makes
//     the service unavailable (fail closed) without touching the file.

import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

export const PACK_KEY_PREFIX = 'sk-pk-';

export function isPackKey(value) {
  return typeof value === 'string' && value.startsWith(PACK_KEY_PREFIX);
}

export class PackError extends Error {
  constructor(code, message) {
    super(message || code);
    this.name = 'PackError';
    this.code = code;
  }
}

const HTTP_STATUS = { invalid: 400, pricing_required: 400, not_found: 404, conflict: 409, rate_limited: 429, unavailable: 503 };
const MODES = ['round_robin', 'random', 'primary_backup'];
const MAX_MEMBERS = 8;
const MAX_KEY_BATCH = 500;
const MIN_TIMEOUT_MS = 1000;
const MAX_TIMEOUT_MS = 120_000;
const DEFAULT_TIMEOUT_MS = 30_000;
const DEFAULT_MAX_ATTEMPTS = 3;
const PERSIST_DEBOUNCE_MS = 500;
const PERSIST_RETRY_MS = 5000;
const PERSIST_FAIL_GRACE_MS = 120_000;
const DAY_MS = 86_400_000;
const CONTROL = /[\u0000-\u001f\u007f]/;

const isPlainObject = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value);
const hasOwn = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
// Ids come from callers; a plain-object lookup would also answer to "__proto__", "constructor", …
const own = (map, id) => (typeof id === 'string' && hasOwn(map, id) ? map[id] : undefined);
const sha256Hex = (value) => crypto.createHash('sha256').update(value).digest('hex');
const round = (value) => Math.round(value * 1e9) / 1e9;
const clone = (value) => structuredClone(value);
const tokenCount = (usage) => (usage.prompt_tokens || 0) + (usage.completion_tokens || 0);
// Numbers an upstream reports are not under our control: they are clamped so that whatever is
// stored is always something the loader accepts again (a safe integer, a finite cost).
const MAX_COUNT = Number.MAX_SAFE_INTEGER;
const MAX_COST_USD = 1e15;
const nonNegative = (value) => (typeof value === 'number' && Number.isFinite(value) && value > 0 ? Math.min(Math.floor(value), MAX_COUNT) : 0);
const saturatingAdd = (a, b) => Math.min(MAX_COUNT, (Number.isSafeInteger(a) ? a : 0) + b);
const priced = (member) => Number.isFinite(member.input_usd_per_1m) && Number.isFinite(member.output_usd_per_1m);

function emptyDoc() {
  return { schema_version: 1, packs: {}, keys: {} };
}

// -------------------------------------------------- scheduled quota restore
// A key may carry `reset`: { unit, every, anchor_at, applied, last_reset_at }. Its boundaries are anchor + n periods
// (n = 1, 2, …), always counted from the anchor, never from the previous boundary, so they cannot drift; a month is
// a calendar month and clamps to the end of a short one. `applied` is how many boundaries have been dealt with. The
// current period's usage is `usage`; what came before is folded into `lifetime`. See
// docs/superpowers/specs/2026-11-02-pack-key-reset-design.md.

const RESET_MAX_EVERY = { day: 366, week: 52, month: 24 };
const MAX_BOUNDARY_SCAN = 100_000;

/** The n-th boundary of a schedule (n = 0 is the anchor itself). */
function boundaryAt(reset, n) {
  const anchor = new Date(reset.anchor_at);
  if (reset.unit === 'month') {
    const total = anchor.getUTCMonth() + n * reset.every;
    const year = anchor.getUTCFullYear() + Math.floor(total / 12);
    const month = ((total % 12) + 12) % 12;
    const lastDay = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
    return new Date(Date.UTC(
      year, month, Math.min(anchor.getUTCDate(), lastDay),
      anchor.getUTCHours(), anchor.getUTCMinutes(), anchor.getUTCSeconds(), anchor.getUTCMilliseconds(),
    ));
  }
  return new Date(anchor.getTime() + n * reset.every * (reset.unit === 'week' ? 7 : 1) * DAY_MS);
}

/** How many boundaries (1, 2, …) are at or before `at`: 0 when the first one is still ahead. */
function passedBoundaries(reset, at) {
  const time = at.getTime();
  if (boundaryAt(reset, 1).getTime() > time) return 0;
  if (reset.unit !== 'month') {
    const periodMs = reset.every * (reset.unit === 'week' ? 7 : 1) * DAY_MS;
    return Math.floor((time - new Date(reset.anchor_at).getTime()) / periodMs);
  }
  let passed = 1;
  while (passed < MAX_BOUNDARY_SCAN && boundaryAt(reset, passed + 1).getTime() <= time) passed += 1;
  return passed;
}

function emptyLifetime() {
  return { prompt_tokens: 0, completion_tokens: 0, cost_usd: 0, requests: 0 };
}

// ------------------------------------------------------------- store checks
// A restored or hand-edited file must not silently switch quota enforcement
// off (a string where a counter belongs would make every comparison false), so
// every field is checked, not just the shape.

const isNonNegInt = (value) => Number.isSafeInteger(value) && value >= 0;
const isNonNegNumber = (value) => typeof value === 'number' && Number.isFinite(value) && value >= 0;
const isPosInt = (value) => Number.isSafeInteger(value) && value > 0;
const isPosNumber = (value) => typeof value === 'number' && Number.isFinite(value) && value > 0;
const isDateText = (value) => typeof value === 'string' && value.length <= 40 && !Number.isNaN(Date.parse(value));
const isPriceOrNull = (value) => value === null || isNonNegNumber(value);

function validPack(id, pack) {
  if (!isPlainObject(pack) || pack.id !== id || typeof pack.name !== 'string' || pack.name.length > 100) return false;
  if (typeof pack.model_id !== 'string' || pack.model_id.length < 1 || pack.model_id.length > 64 || CONTROL.test(pack.model_id)) return false;
  if (typeof pack.enabled !== 'boolean' || !MODES.includes(pack.mode)) return false;
  if ('identity' in pack && typeof pack.identity !== 'boolean') return false;
  if (!Array.isArray(pack.members) || pack.members.length < 1 || pack.members.length > MAX_MEMBERS) return false;
  const seen = new Set();
  for (const member of pack.members) {
    if (!isPlainObject(member) || typeof member.model !== 'string' || member.model.length < 1 || member.model.length > 200) return false;
    if (!isPriceOrNull(member.input_usd_per_1m) || !isPriceOrNull(member.output_usd_per_1m)) return false;
    if (seen.has(member.model.toLowerCase())) return false;
    seen.add(member.model.toLowerCase());
  }
  const failover = pack.failover;
  if (!isPlainObject(failover)) return false;
  if (!Number.isInteger(failover.first_byte_timeout_ms) || failover.first_byte_timeout_ms < MIN_TIMEOUT_MS || failover.first_byte_timeout_ms > MAX_TIMEOUT_MS) return false;
  if (!Number.isInteger(failover.max_attempts) || failover.max_attempts < 1 || failover.max_attempts > pack.members.length) return false;
  return typeof pack.created_at === 'string' && typeof pack.updated_at === 'string';
}

function validReset(reset) {
  if (!isPlainObject(reset) || !hasOwn(RESET_MAX_EVERY, reset.unit)) return false;
  if (!Number.isInteger(reset.every) || reset.every < 1 || reset.every > RESET_MAX_EVERY[reset.unit]) return false;
  if (!isDateText(reset.anchor_at) || !isNonNegInt(reset.applied)) return false;
  return reset.last_reset_at === null || isDateText(reset.last_reset_at);
}

function validLifetime(life) {
  return isPlainObject(life) && isNonNegInt(life.prompt_tokens) && isNonNegInt(life.completion_tokens)
    && isNonNegNumber(life.cost_usd) && isNonNegInt(life.requests);
}

function validKey(id, key, packs) {
  if (!isPlainObject(key) || key.id !== id || typeof key.pack_id !== 'string' || !hasOwn(packs, key.pack_id)) return false;
  if (typeof key.key_hash !== 'string' || !/^[0-9a-f]{64}$/.test(key.key_hash)) return false;
  if (typeof key.key_tail !== 'string' || key.key_tail.length > 8 || typeof key.label !== 'string' || key.label.length > 100) return false;
  if (typeof key.enabled !== 'boolean' || typeof key.created_at !== 'string') return false;
  if (key.expires_at !== null && !isDateText(key.expires_at)) return false;
  const { limits, usage, owner } = key;
  if (!isPlainObject(limits) || (limits.total_tokens !== null && !isPosInt(limits.total_tokens))) return false;
  if (limits.total_cost_usd !== null && !isPosNumber(limits.total_cost_usd)) return false;
  if (!isPlainObject(usage) || !isNonNegInt(usage.prompt_tokens) || !isNonNegInt(usage.completion_tokens)) return false;
  if (!isNonNegNumber(usage.cost_usd) || !isNonNegInt(usage.requests)) return false;
  if (usage.last_used_at !== null && typeof usage.last_used_at !== 'string') return false;
  // owner.qtc_user_id: an external account id (UUID). Kept so existing stores load unchanged.
  if (owner !== null && !(isPlainObject(owner) && typeof owner.qtc_user_id === 'string' && owner.qtc_user_id && typeof owner.bound_at === 'string')) return false;
  if ('key_enc' in key && key.key_enc !== null && !(typeof key.key_enc === 'string' && key.key_enc.length <= 512)) return false;
  // A schedule that cannot be understood must not quietly switch restores off, or on at the wrong time.
  if ('reset' in key && key.reset !== null && !validReset(key.reset)) return false;
  if ('lifetime' in key && !validLifetime(key.lifetime)) return false;
  // A cost limit is meaningless (never reached) if a member cannot be priced.
  if (limits.total_cost_usd !== null && !packs[key.pack_id].members.every(priced)) return false;
  return true;
}

function validDoc(doc) {
  if (!isPlainObject(doc) || doc.schema_version !== 1 || !isPlainObject(doc.packs) || !isPlainObject(doc.keys)) return false;
  for (const [id, pack] of Object.entries(doc.packs)) if (!validPack(id, pack)) return false;
  const hashes = new Set();
  for (const [id, key] of Object.entries(doc.keys)) {
    if (!validKey(id, key, doc.packs)) return false;
    if (hashes.has(key.key_hash)) return false;
    hashes.add(key.key_hash);
  }
  return true;
}

export function createPackService({
  storePath,
  now = () => new Date(),
  random = Math.random,
  logger = console,
  fsImpl = fs,
  retryMs = PERSIST_RETRY_MS,
  cipher = null,
} = {}) {
  if (!storePath) throw new Error('storePath is required');

  let doc = emptyDoc();
  let ok = true;
  const byHash = new Map();
  const cursors = new Map();
  let dirty = false;
  let timer = null;
  let failingSince = null;

  // ------------------------------------------------------------------ store

  function load() {
    if (!fsImpl.existsSync(storePath)) return;
    try {
      const stat = fsImpl.statSync(storePath);
      if (!stat.isFile()) throw new Error('not a regular file');
      const parsed = JSON.parse(fsImpl.readFileSync(storePath, 'utf8'));
      if (!validDoc(parsed)) throw new Error('unexpected structure or field values');
      doc = parsed;
      if (stat.mode & 0o077) {
        // A restored copy can arrive world-readable; the file holds key hashes and account ids.
        try {
          fsImpl.chmodSync(storePath, 0o600);
          logger.warn?.('[packs] tightened the store file permissions to 0600');
        } catch (error) {
          logger.warn?.(`[packs] could not tighten the store file permissions: ${error.message}`);
        }
      }
    } catch (error) {
      ok = false;
      logger.error?.(`[packs] store unreadable, pack keys are disabled: ${error.message}`);
    }
  }

  function indexKeys() {
    byHash.clear();
    for (const key of Object.values(doc.keys)) byHash.set(key.key_hash, key.id);
  }

  function isAvailable() {
    return ok && !(failingSince !== null && now().getTime() - failingSince >= PERSIST_FAIL_GRACE_MS);
  }

  function noteWriteFailure(error) {
    dirty = true;
    if (failingSince === null) failingSince = now().getTime();
    logger.error?.(`[packs] could not write the store: ${error.message}`);
  }

  // Writes the document if it changed. Throws on failure and leaves `dirty` set.
  function persistNow() {
    if (!ok || !dirty) return;
    dirty = false;
    try {
      // Defence in depth: refuse to write anything the loader would refuse to read back.
      if (!validDoc(doc)) throw new Error('refusing to write a store the loader would reject');
      fsImpl.mkdirSync(path.dirname(storePath), { recursive: true, mode: 0o700 });
      const tmp = `${storePath}.${process.pid}.tmp`;
      const fd = fsImpl.openSync(tmp, 'w', 0o600);
      try {
        fsImpl.writeFileSync(fd, JSON.stringify(doc));
        fsImpl.fsyncSync(fd);
      } finally {
        fsImpl.closeSync(fd);
      }
      fsImpl.renameSync(tmp, storePath);
      fsImpl.chmodSync(storePath, 0o600);
      failingSince = null;
    } catch (error) {
      dirty = true;
      throw error;
    }
  }

  function schedule(delay) {
    if (timer) return;
    timer = setTimeout(() => {
      timer = null;
      try {
        persistNow();
      } catch (error) {
        noteWriteFailure(error);
        schedule(retryMs);
      }
    }, delay);
    timer.unref?.();
  }

  function markDirty() {
    dirty = true;
    schedule(PERSIST_DEBOUNCE_MS);
  }

  function clearTimer() {
    if (timer) {
      clearTimeout(timer);
      timer = null;
    }
  }

  function flushSync() {
    clearTimer();
    try {
      persistNow();
    } catch (error) {
      noteWriteFailure(error);
      schedule(retryMs);
    }
  }

  // For changes a caller will be told succeeded: they are on disk before this returns.
  function persistDurably() {
    clearTimer();
    dirty = true;
    try {
      persistNow();
    } catch (error) {
      noteWriteFailure(error);
      schedule(retryMs);
      throw new PackError('unavailable', 'The model pack store could not be saved.');
    }
  }

  function writable() {
    if (!isAvailable()) throw new PackError('unavailable', 'The model pack store is unavailable.');
  }

  // An admin change is all or nothing: if it cannot be written, the in-memory state goes back
  // to exactly what it was, so the caller's error is the truth and a retry cannot duplicate it.
  function transact(change) {
    const snapshot = structuredClone(doc);
    try {
      const result = change();
      persistDurably();
      return result;
    } catch (error) {
      doc = snapshot;
      indexKeys();
      throw error;
    }
  }

  load();
  indexKeys();

  // ------------------------------------------------------------- validation

  function text(value, field, { min = 0, max, required = false } = {}) {
    if (value === undefined || value === null) {
      if (required) throw new PackError('invalid', `${field} is required`);
      return '';
    }
    if (typeof value !== 'string') throw new PackError('invalid', `${field} must be a string`);
    const trimmed = value.trim();
    if (CONTROL.test(trimmed)) throw new PackError('invalid', `${field} contains control characters`);
    if (trimmed.length < min || trimmed.length > max) {
      throw new PackError('invalid', `${field} must be ${min}-${max} characters`);
    }
    return trimmed;
  }

  function price(value, field) {
    if (value === undefined || value === null) return null;
    if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) {
      throw new PackError('invalid', `${field} must be a number >= 0 or null`);
    }
    return value;
  }

  function expiry(value) {
    if (value === undefined || value === null || value === '') return null;
    const date = new Date(value);
    if (typeof value !== 'string' || Number.isNaN(date.getTime())) {
      throw new PackError('invalid', 'expires_at must be a valid ISO-8601 timestamp');
    }
    return date.toISOString();
  }

  function positiveInt(value, field) {
    if (value === undefined || value === null) return null;
    if (!Number.isSafeInteger(value) || value <= 0) throw new PackError('invalid', `${field} must be a positive integer or null`);
    return value;
  }

  function positiveNumber(value, field) {
    if (value === undefined || value === null) return null;
    if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0) {
      throw new PackError('invalid', `${field} must be a positive number or null`);
    }
    return value;
  }

  /**
   * A schedule from a caller: undefined = not given, null = none, or { unit, every, anchor_at? }. The anchor is when it
   * is set unless the caller aligns it (a past one for "the 1st of every month"; at most a day ahead, for clocks that
   * are a little off). Boundaries that are already behind are not restored for: only the next ones are.
   */
  function resetSchedule(raw) {
    if (raw === undefined) return undefined;
    if (raw === null) return null;
    if (!isPlainObject(raw)) throw new PackError('invalid', 'reset must be an object or null');
    if (!hasOwn(RESET_MAX_EVERY, raw.unit)) throw new PackError('invalid', 'reset.unit must be day, week or month');
    if (!Number.isInteger(raw.every) || raw.every < 1 || raw.every > RESET_MAX_EVERY[raw.unit]) {
      throw new PackError('invalid', `reset.every must be an integer 1-${RESET_MAX_EVERY[raw.unit]} for ${raw.unit}`);
    }
    const current = now();
    let anchor = current;
    if (raw.anchor_at !== undefined && raw.anchor_at !== null) {
      anchor = new Date(raw.anchor_at);
      if (typeof raw.anchor_at !== 'string' || Number.isNaN(anchor.getTime())) {
        throw new PackError('invalid', 'reset.anchor_at must be a valid ISO-8601 timestamp');
      }
      if (anchor.getTime() > current.getTime() + DAY_MS) throw new PackError('invalid', 'reset.anchor_at is more than a day in the future');
    }
    const schedule = { unit: raw.unit, every: raw.every, anchor_at: anchor.toISOString(), applied: 0, last_reset_at: null };
    schedule.applied = passedBoundaries(schedule, current);
    return schedule;
  }

  /** The current period's usage becomes part of the lifetime totals, and the period starts again from zero. */
  function foldUsage(key) {
    const life = key.lifetime ?? emptyLifetime();
    life.prompt_tokens = saturatingAdd(life.prompt_tokens, key.usage.prompt_tokens);
    life.completion_tokens = saturatingAdd(life.completion_tokens, key.usage.completion_tokens);
    life.cost_usd = Math.min(MAX_COST_USD, (Number.isFinite(life.cost_usd) ? life.cost_usd : 0) + (Number.isFinite(key.usage.cost_usd) ? key.usage.cost_usd : 0));
    life.requests = saturatingAdd(life.requests, key.usage.requests);
    key.lifetime = life;
    key.usage.prompt_tokens = 0;
    key.usage.completion_tokens = 0;
    key.usage.cost_usd = 0;
    key.usage.requests = 0;
  }

  /**
   * Restores the key once if a boundary has passed since it was last looked at. Called wherever usage is read or added,
   * so there is no timer to miss: a boundary that came and went while nobody looked (or the gateway was down) is
   * dealt with at the next look, once however many were missed, and the next boundary stays on the schedule's grid.
   * Idempotent; the write is debounced like any usage.
   */
  function settle(key, at = now()) {
    const reset = key.reset;
    if (!reset) return;
    const passed = passedBoundaries(reset, at);
    if (passed <= reset.applied) return;
    foldUsage(key);
    reset.applied = passed;
    reset.last_reset_at = boundaryAt(reset, passed).toISOString();
    markDirty();
  }

  function requirePricing(pack) {
    if (!pack.members.every(priced)) {
      throw new PackError('pricing_required', 'Every member needs input and output prices before a cost limit can be used.');
    }
  }

  function packOf(id) {
    const pack = own(doc.packs, id);
    if (!pack) throw new PackError('not_found', 'Pack not found.');
    return pack;
  }

  function keyOf(id) {
    const key = own(doc.keys, id);
    if (!key) throw new PackError('not_found', 'Key not found.');
    return key;
  }

  // ------------------------------------------------------------------ state

  function keyState(key, pack, at = now()) {
    settle(key, at);
    if (!key.enabled || !pack || !pack.enabled) return 'disabled';
    if (key.expires_at && new Date(key.expires_at) <= at) return 'expired';
    if (key.limits.total_tokens != null && tokenCount(key.usage) >= key.limits.total_tokens) return 'exhausted';
    if (key.limits.total_cost_usd != null && key.usage.cost_usd >= key.limits.total_cost_usd) return 'exhausted';
    return 'active';
  }

  function resetView(key) {
    const reset = key.reset;
    if (!reset) return null;
    return {
      unit: reset.unit,
      every: reset.every,
      anchor_at: reset.anchor_at,
      next_reset_at: boundaryAt(reset, reset.applied + 1).toISOString(),
      last_reset_at: reset.last_reset_at ?? null,
    };
  }

  function lifetimeView(key) {
    const life = key.lifetime ?? emptyLifetime();
    return {
      prompt_tokens: life.prompt_tokens,
      completion_tokens: life.completion_tokens,
      tokens: life.prompt_tokens + life.completion_tokens,
      cost_usd: round(life.cost_usd),
      requests: life.requests,
    };
  }

  function statusView(key, pack) {
    const at = now();
    settle(key, at);
    const used = tokenCount(key.usage);
    const tokenLimit = key.limits.total_tokens ?? null;
    const costLimit = key.limits.total_cost_usd ?? null;
    const costUsed = round(key.usage.cost_usd || 0);
    return {
      handle: key.id,
      model: pack.model_id,
      key_tail: key.key_tail,
      status: keyState(key, pack, at),
      expires_at: key.expires_at ?? null,
      days_left: key.expires_at ? Math.max(0, Math.ceil((new Date(key.expires_at) - at) / DAY_MS)) : null,
      tokens: { used, limit: tokenLimit, remaining: tokenLimit == null ? null : Math.max(0, tokenLimit - used) },
      cost_usd: {
        used: costUsed,
        limit: costLimit,
        remaining: costLimit == null ? null : Math.max(0, round(costLimit - (key.usage.cost_usd || 0))),
      },
      last_used_at: key.usage.last_used_at ?? null,
      // When the quota comes back, and on what schedule (null when it does not): the meters above are this period's.
      resets_at: key.reset ? resetView(key).next_reset_at : null,
      reset_every: key.reset ? { unit: key.reset.unit, every: key.reset.every } : null,
      // A sealed copy exists, so the owner's page can offer Copy (never without a cipher).
      copyable: Boolean(cipher && key.key_enc),
    };
  }

  function keyView(key) {
    const pack = doc.packs[key.pack_id];
    settle(key, now());
    return {
      id: key.id,
      pack_id: key.pack_id,
      label: key.label,
      tail: key.key_tail,
      enabled: key.enabled,
      status: keyState(key, pack),
      expires_at: key.expires_at ?? null,
      limits: { total_tokens: key.limits.total_tokens ?? null, total_cost_usd: key.limits.total_cost_usd ?? null },
      usage: {
        prompt_tokens: key.usage.prompt_tokens || 0,
        completion_tokens: key.usage.completion_tokens || 0,
        tokens: tokenCount(key.usage),
        cost_usd: round(key.usage.cost_usd || 0),
        requests: key.usage.requests || 0,
        last_used_at: key.usage.last_used_at ?? null,
      },
      reset: resetView(key),
      lifetime: lifetimeView(key),
      bound: Boolean(key.owner),
      owner_id: key.owner?.qtc_user_id ?? null,
      bound_at: key.owner?.bound_at ?? null,
      created_at: key.created_at,
    };
  }

  // ------------------------------------------------------------------ packs

  function normalizeMembers(raw) {
    if (!Array.isArray(raw) || raw.length < 1 || raw.length > MAX_MEMBERS) {
      throw new PackError('invalid', `members must contain 1-${MAX_MEMBERS} models`);
    }
    const seen = new Set();
    return raw.map((member, index) => {
      if (!isPlainObject(member)) throw new PackError('invalid', `members[${index}] must be an object`);
      const model = text(member.model, `members[${index}].model`, { min: 1, max: 200, required: true });
      if (seen.has(model.toLowerCase())) throw new PackError('invalid', `members contains ${model} twice`);
      seen.add(model.toLowerCase());
      return {
        model,
        input_usd_per_1m: price(member.input_usd_per_1m, `members[${index}].input_usd_per_1m`),
        output_usd_per_1m: price(member.output_usd_per_1m, `members[${index}].output_usd_per_1m`),
      };
    });
  }

  function normalizeFailover(raw, memberCount) {
    const input = isPlainObject(raw) ? raw : {};
    const timeout = input.first_byte_timeout_ms ?? DEFAULT_TIMEOUT_MS;
    if (!Number.isInteger(timeout) || timeout < MIN_TIMEOUT_MS || timeout > MAX_TIMEOUT_MS) {
      throw new PackError('invalid', `first_byte_timeout_ms must be ${MIN_TIMEOUT_MS}-${MAX_TIMEOUT_MS}`);
    }
    const attempts = input.max_attempts ?? Math.min(DEFAULT_MAX_ATTEMPTS, memberCount);
    if (!Number.isInteger(attempts) || attempts < 1 || attempts > memberCount) {
      throw new PackError('invalid', `max_attempts must be 1-${memberCount}`);
    }
    return { first_byte_timeout_ms: timeout, max_attempts: attempts };
  }

  function upsertPack(input) {
    writable();
    if (!isPlainObject(input)) throw new PackError('invalid', 'pack must be an object');
    const existing = input.id ? own(doc.packs, input.id) : null;
    if (input.id && !existing) throw new PackError('not_found', 'Pack not found.');
    const modelId = text(input.model_id, 'model_id', { min: 1, max: 64, required: true });
    if (!MODES.includes(input.mode)) throw new PackError('invalid', `mode must be one of ${MODES.join(', ')}`);
    const members = normalizeMembers(input.members);
    const failover = normalizeFailover(input.failover, members.length);
    const candidate = {
      id: existing?.id || `pk_${crypto.randomBytes(8).toString('hex')}`,
      name: text(input.name, 'name', { max: 100 }) || modelId,
      model_id: modelId,
      enabled: input.enabled !== false,
      // Whichever member answers introduces itself as this pack's public name (pack-identity.mjs). On unless turned off.
      identity: input.identity === undefined ? existing?.identity !== false : input.identity !== false,
      mode: input.mode,
      members,
      failover,
      created_at: existing?.created_at || now().toISOString(),
      updated_at: now().toISOString(),
    };
    const hasCostKeys = Object.values(doc.keys).some((key) => key.pack_id === candidate.id && key.limits.total_cost_usd != null);
    if (hasCostKeys) requirePricing(candidate);
    transact(() => { doc.packs[candidate.id] = candidate; });
    return clone(candidate);
  }

  function deletePack(id) {
    writable();
    packOf(id);
    transact(() => {
      for (const key of Object.values(doc.keys)) {
        if (key.pack_id !== id) continue;
        byHash.delete(key.key_hash);
        delete doc.keys[key.id];
      }
      delete doc.packs[id];
    });
    cursors.delete(id);
  }

  function getPack(id) {
    const pack = own(doc.packs, id);
    return pack ? clone(pack) : null;
  }

  function listPacks() {
    return Object.values(doc.packs).map((pack) => {
      const keys = Object.values(doc.keys).filter((key) => key.pack_id === pack.id);
      return {
        ...clone(pack),
        identity: pack.identity !== false,
        key_count: keys.length,
        active_key_count: keys.filter((key) => keyState(key, pack) === 'active').length,
      };
    });
  }

  // ------------------------------------------------------------------- keys

  function createKeys({ packId, count, labelPrefix, expiresAt, totalTokens, totalCostUsd, reset } = {}) {
    writable();
    const pack = packOf(packId);
    if (!Number.isInteger(count) || count < 1 || count > MAX_KEY_BATCH) {
      throw new PackError('invalid', `count must be an integer 1-${MAX_KEY_BATCH}`);
    }
    const prefix = text(labelPrefix, 'label_prefix', { max: 80 });
    const expires = expiry(expiresAt);
    const tokens = positiveInt(totalTokens, 'total_tokens');
    const cost = positiveNumber(totalCostUsd, 'total_cost_usd');
    if (cost != null) requirePricing(pack);
    const schedule = resetSchedule(reset) ?? null;

    const created = [];
    const createdAt = now().toISOString();
    // The plaintext is only handed out if the keys were saved; otherwise nothing is left behind.
    transact(() => {
      for (let index = 1; index <= count; index += 1) {
        const plain = PACK_KEY_PREFIX + crypto.randomBytes(32).toString('base64url');
        const id = `pkk_${crypto.randomBytes(8).toString('hex')}`;
        const label = prefix ? (count > 1 ? `${prefix}-${index}` : prefix) : '';
        doc.keys[id] = {
          id,
          pack_id: pack.id,
          key_hash: sha256Hex(plain),
          key_tail: plain.slice(-4),
          label,
          enabled: true,
          expires_at: expires,
          limits: { total_tokens: tokens, total_cost_usd: cost },
          usage: { prompt_tokens: 0, completion_tokens: 0, cost_usd: 0, requests: 0, last_used_at: null },
          reset: schedule ? { ...schedule } : null,
          owner: null,
          created_at: createdAt,
        };
        byHash.set(doc.keys[id].key_hash, id);
        created.push({ id, key: plain, tail: plain.slice(-4), label });
      }
    });
    return { keys: created };
  }

  function listKeys(packId) {
    packOf(packId);
    return Object.values(doc.keys).filter((key) => key.pack_id === packId).map(keyView);
  }

  function updateKey(id, patch = {}) {
    writable();
    const key = keyOf(id);
    const pack = packOf(key.pack_id);
    // A boundary that has passed is dealt with before the schedule or the limits change, so the old period is closed first.
    settle(key, now());
    const next = {
      label: key.label,
      enabled: key.enabled,
      expires_at: key.expires_at,
      limits: { ...key.limits },
    };
    // A new schedule starts counting now (or at the anchor the caller gives); it does not restore anything by itself.
    if (hasOwn(patch, 'reset')) {
      const schedule = resetSchedule(patch.reset);
      if (schedule !== undefined) next.reset = schedule;
    }
    if (hasOwn(patch, 'label')) next.label = text(patch.label, 'label', { max: 100 });
    if (hasOwn(patch, 'enabled')) {
      if (typeof patch.enabled !== 'boolean') throw new PackError('invalid', 'enabled must be a boolean');
      next.enabled = patch.enabled;
    }
    if (hasOwn(patch, 'expires_at')) next.expires_at = expiry(patch.expires_at);
    if (hasOwn(patch, 'total_tokens')) next.limits.total_tokens = positiveInt(patch.total_tokens, 'total_tokens');
    if (hasOwn(patch, 'total_cost_usd')) {
      next.limits.total_cost_usd = positiveNumber(patch.total_cost_usd, 'total_cost_usd');
      if (next.limits.total_cost_usd != null) requirePricing(pack);
    }
    transact(() => { Object.assign(key, next); });
    return keyView(key);
  }

  function deleteKey(id) {
    writable();
    const key = keyOf(id);
    transact(() => {
      byHash.delete(key.key_hash);
      delete doc.keys[id];
    });
  }

  function unbindKey(id) {
    writable();
    const key = keyOf(id);
    transact(() => {
      key.owner = null;
      key.key_enc = null;
    });
    return keyView(key);
  }

  // The returned objects are live references: callers must treat them as read-only.
  function resolveKey(plain) {
    if (!isAvailable() || !isPackKey(plain)) return null;
    const id = byHash.get(sha256Hex(plain));
    const key = id ? doc.keys[id] : null;
    const pack = key ? doc.packs[key.pack_id] : null;
    // A request that arrives after a boundary finds the quota already restored.
    if (key) settle(key, now());
    return key && pack ? { key, pack } : null;
  }

  /** Restores the quota now (the owner's "restore once"): the schedule, if there is one, keeps its grid. */
  function resetUsage(id) {
    writable();
    const key = keyOf(id);
    transact(() => {
      const current = now();
      settle(key, current);
      foldUsage(key);
      if (key.reset) key.reset.last_reset_at = current.toISOString();
    });
    return keyView(key);
  }

  // -------------------------------------------------------------- scheduling

  function memberOrder(pack) {
    const members = pack.members.map((member) => ({ ...member }));
    if (pack.mode === 'round_robin') {
      const cursor = cursors.get(pack.id) || 0;
      cursors.set(pack.id, cursor + 1);
      const start = cursor % members.length;
      return [...members.slice(start), ...members.slice(0, start)];
    }
    if (pack.mode === 'random') {
      for (let i = members.length - 1; i > 0; i -= 1) {
        const j = Math.floor(random() * (i + 1));
        [members[i], members[j]] = [members[j], members[i]];
      }
    }
    return members;
  }

  // ------------------------------------------------------------------ usage

  // `prices` is the answering member's price as it was when the attempt began, so
  // editing the pack while a request is in flight cannot change what that request
  // costs. Without it the current pack's member of the same name is used.
  function recordUsage(keyId, { promptTokens = 0, completionTokens = 0, memberModel = '', prices = null } = {}) {
    const key = own(doc.keys, keyId);
    if (!ok || !key) return;
    const pack = doc.packs[key.pack_id];
    const prompt = nonNegative(promptTokens);
    const completion = nonNegative(completionTokens);
    const member = prices || pack?.members.find((m) => m.model.toLowerCase() === String(memberModel).toLowerCase());
    // No rounding here: a charge below the display precision must still add up.
    let cost = member && priced(member)
      ? (prompt / 1e6) * member.input_usd_per_1m + (completion / 1e6) * member.output_usd_per_1m
      : 0;
    if (!Number.isFinite(cost) || cost < 0) cost = MAX_COST_USD;
    // What a request spends after a boundary belongs to the new period, even if nothing looked at the key first.
    settle(key, now());
    key.usage.prompt_tokens = saturatingAdd(key.usage.prompt_tokens, prompt);
    key.usage.completion_tokens = saturatingAdd(key.usage.completion_tokens, completion);
    key.usage.cost_usd = Math.min(MAX_COST_USD, (Number.isFinite(key.usage.cost_usd) ? key.usage.cost_usd : 0) + cost);
    key.usage.requests = saturatingAdd(key.usage.requests, 1);
    key.usage.last_used_at = now().toISOString();
    markDirty();
  }

  // ------------------------------------------------------------------ admin

  // POST /cpa-admin/packs/save. Body: { action, ... }
  //   upsert_pack  { pack }                                   -> { pack }
  //   delete_pack  { pack_id }                                -> { ok }
  //   create_keys  { pack_id, count, label_prefix?, expires_at?, total_tokens?, total_cost_usd?, reset? }
  //                                                           -> { keys: [{ id, key, tail, label }] }  (plaintext, once)
  //   update_key   { key_id, label?, enabled?, expires_at?, total_tokens?, total_cost_usd?, reset? }  (null clears) -> { key }
  //                (reset: { unit: day|week|month, every, anchor_at? } = restore the quota on that schedule; null = never)
  //   reset_usage  { key_id }                                 -> { key }  (restore the quota now; the schedule keeps its grid)
  //   delete_key   { key_id }                                 -> { ok }
  //   unbind_key   { key_id }                                 -> { key }
  function applyAdminAction(body) {
    try {
      if (!isPlainObject(body)) return { status: 400, body: { error: 'Invalid request body' } };
      switch (body.action) {
        case 'upsert_pack':
          return { status: 200, body: { pack: upsertPack(body.pack) } };
        case 'delete_pack':
          deletePack(body.pack_id);
          return { status: 200, body: { ok: true } };
        case 'create_keys':
          return {
            status: 200,
            body: createKeys({
              packId: body.pack_id,
              count: body.count,
              labelPrefix: body.label_prefix,
              expiresAt: body.expires_at,
              totalTokens: body.total_tokens,
              totalCostUsd: body.total_cost_usd,
              reset: body.reset,
            }),
          };
        case 'update_key': {
          const { action, key_id: keyId, ...patch } = body;
          void action;
          return { status: 200, body: { key: updateKey(keyId, patch) } };
        }
        case 'delete_key':
          deleteKey(body.key_id);
          return { status: 200, body: { ok: true } };
        case 'reset_usage':
          return { status: 200, body: { key: resetUsage(body.key_id) } };
        case 'unbind_key':
          return { status: 200, body: { key: unbindKey(body.key_id) } };
        default:
          return { status: 400, body: { error: 'Unknown action' } };
      }
    } catch (error) {
      if (error instanceof PackError) {
        return { status: HTTP_STATUS[error.code] || 400, body: { error: error.message, code: error.code } };
      }
      throw error;
    }
  }

  return {
    available: isAvailable,
    health: () => ({ available: isAvailable(), store_readable: ok, persistence_failing: failingSince !== null }),
    upsertPack,
    deletePack,
    getPack,
    listPacks,
    createKeys,
    listKeys,
    updateKey,
    deleteKey,
    unbindKey,
    resetUsage,
    resolveKey,
    keyState,
    statusView,
    memberOrder,
    recordUsage,
    applyAdminAction,
    flushSync,
  };
}
