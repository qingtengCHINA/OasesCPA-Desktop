// catalog.mjs — public model metadata for /v1/models (display name, context
// length, input/output modalities, supported parameters, max output tokens).
//
// The engine's /v1/models only returns id/object/created/owned_by. Most Oases
// models are served through OpenRouter, whose public catalog
// (GET https://openrouter.ai/api/v1/models, no key) carries exactly this
// metadata. It is refreshed in the background and cached on disk so a gateway
// restart or an OpenRouter outage never blocks /v1/models.
//
// MODEL_CATALOG_URL picks another catalog endpoint (same JSON shape), or "off": the gateway then
// never opens a connection for it. A cache file that is already on disk is still read.
//
// Pure Node stdlib, Node 18+.

import fs from 'fs';
import path from 'path';
import { resolveGatewayPaths } from './paths.mjs';

const REFRESH_INTERVAL_MS = 12 * 60 * 60 * 1000;
const RETRY_INTERVAL_MS = 10 * 60 * 1000;
const FETCH_TIMEOUT_MS = 15000;

function pickMetadata(model) {
  const architecture = model?.architecture || {};
  const meta = {
    vendor: typeof model?.id === 'string' && model.id.includes('/') ? model.id.split('/')[0] : null,
    name: typeof model?.name === 'string' ? model.name : null,
    context_length: Number.isFinite(Number(model?.context_length)) ? Number(model.context_length) : null,
    max_output_tokens: Number.isFinite(Number(model?.top_provider?.max_completion_tokens))
      ? Number(model.top_provider.max_completion_tokens)
      : null,
    architecture: {
      input_modalities: Array.isArray(architecture.input_modalities) ? architecture.input_modalities : [],
      output_modalities: Array.isArray(architecture.output_modalities) ? architecture.output_modalities : [],
    },
    supported_parameters: Array.isArray(model?.supported_parameters) ? model.supported_parameters : [],
  };
  return meta;
}

export function createModelCatalog(options = {}) {
  // "off" (any case, blanks around it ignored) in place of a url closes the network side.
  const offline = typeof options.url === 'string' && options.url.trim().toLowerCase() === 'off';
  const url = options.url || 'https://openrouter.ai/api/v1/models';
  const cachePath = options.cachePath || resolveGatewayPaths().modelCatalogCachePath;
  const fetchImpl = options.fetchImpl || globalThis.fetch;
  const now = options.now || (() => Date.now());

  let byId = new Map();
  let bySlug = new Map();
  let fetchedAt = 0;
  let lastAttemptAt = 0;
  let inFlight = null;

  function index(models) {
    const ids = new Map();
    const slugCounts = new Map();
    const slugs = new Map();
    for (const model of Array.isArray(models) ? models : []) {
      if (typeof model?.id !== 'string') continue;
      const meta = pickMetadata(model);
      ids.set(model.id.toLowerCase(), meta);
      // Variants such as ":free" share the base model's metadata; index the slug
      // (after the vendor prefix) only when it is unambiguous.
      const slug = model.id.split('/').pop().split(':')[0].toLowerCase();
      slugCounts.set(slug, (slugCounts.get(slug) || 0) + (model.id.includes(':') ? 0 : 1));
      if (!model.id.includes(':')) slugs.set(slug, meta);
    }
    for (const [slug, count] of slugCounts) {
      if (count !== 1) slugs.delete(slug);
    }
    byId = ids;
    bySlug = slugs;
  }

  try {
    const cached = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
    index(cached.models);
    fetchedAt = Number(cached.fetched_at) || 0;
  } catch {
    // No cache yet: the first /v1/models call triggers a background fetch.
  }

  async function refresh() {
    if (offline) return byId.size;
    lastAttemptAt = now();
    const response = await fetchImpl(url, { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(FETCH_TIMEOUT_MS) });
    if (!response.ok) throw new Error(`catalog HTTP ${response.status}`);
    const body = await response.json();
    const models = Array.isArray(body?.data) ? body.data : [];
    if (!models.length) throw new Error('catalog returned no models');
    // Persist only what we serve, not the whole upstream payload.
    const slim = models.map((model) => ({ id: model.id, ...model, description: undefined, pricing: undefined }));
    index(slim);
    fetchedAt = now();
    try {
      fs.mkdirSync(path.dirname(cachePath), { recursive: true });
      const tmp = `${cachePath}.tmp-${process.pid}`;
      fs.writeFileSync(tmp, JSON.stringify({ fetched_at: fetchedAt, models: slim }), { mode: 0o600 });
      fs.renameSync(tmp, cachePath);
    } catch (error) {
      console.error('[catalog] cache write failed:', error.message);
    }
    return byId.size;
  }

  // Non-blocking: kicks off a refresh when stale, never awaits it on the request path.
  function maybeRefresh() {
    if (offline) return null;
    const stale = now() - fetchedAt > REFRESH_INTERVAL_MS;
    const cooledDown = now() - lastAttemptAt > RETRY_INTERVAL_MS;
    if (!inFlight && stale && cooledDown) {
      inFlight = refresh()
        .catch((error) => console.error('[catalog] refresh failed:', error.message))
        .finally(() => { inFlight = null; });
    }
    return inFlight;
  }

  // upstreamName is the provider-side id (e.g. "x-ai/grok-4.3"); alias is the
  // public id (e.g. "grok-4.3"). Exact id first, then an unambiguous slug.
  function lookup(upstreamName, alias) {
    const exact = byId.get(String(upstreamName || '').toLowerCase());
    if (exact) return exact;
    for (const candidate of [upstreamName, alias]) {
      const slug = String(candidate || '').split('/').pop().split(':')[0].toLowerCase();
      if (slug && bySlug.has(slug)) return bySlug.get(slug);
    }
    return null;
  }

  return { lookup, maybeRefresh, refresh, size: () => byId.size, fetchedAt: () => fetchedAt };
}
