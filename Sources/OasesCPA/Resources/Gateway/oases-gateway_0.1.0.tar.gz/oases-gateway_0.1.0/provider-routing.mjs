// Pure helpers for the engine's openai-compatibility providers, used by the gateway to
// order the providers that serve a model and to route a request to one of them.
//
// The engine can give a provider a `prefix`. Once it does, a request for "<prefix>/<alias>"
// goes to that provider only, and /v1/models also lists a "<prefix>/<alias>" entry for each
// of its models. Those entries are the engine's internal addresses: clients must never see
// them (isInternalModelId) and never address them directly.
//
// config.yaml is read with a small line parser (the project has no yaml dependency); it only
// understands the shapes the engine writes for `openai-compatibility`.
import crypto from 'node:crypto';

// Internal prefix for a provider that has none yet: "pin-" + the name in lower case with
// every run of characters outside [a-z0-9] turned into "-". A name with nothing left
// (e.g. all Chinese) uses the first 8 hex digits of the sha1 of the name instead.
// utils/internalPrefix.ts in the panel must produce exactly the same strings.
export function internalPrefixFor(name) {
  const text = String(name ?? '');
  const slug = text.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  if (slug) return `pin-${slug}`;
  return `pin-${crypto.createHash('sha1').update(text, 'utf8').digest('hex').slice(0, 8)}`;
}

// Same quote handling the gateway has always used for names and aliases.
const unquote = (raw) => String(raw ?? '').replace(/"/g, '').replace(/'/g, '').trim();
// For the newer keys, which people annotate: drop a trailing "# comment" too.
const scalar = (raw) => unquote(String(raw ?? '').replace(/\s+#.*$/, ''));

// "key: value" -> [key, value]; anything else -> null.
function splitField(text) {
  const match = /^([A-Za-z0-9_-]+):(?:\s+(.*))?$/.exec(text);
  return match ? [match[1], match[2] ?? ''] : null;
}

function applyProviderField(provider, field) {
  if (!field) return false;
  const [key, value] = field;
  switch (key) {
    case 'name':
      provider.name = unquote(value);
      return false;
    case 'prefix':
      provider.prefix = scalar(value) || null;
      return false;
    case 'priority': {
      const priority = Number.parseInt(scalar(value), 10);
      provider.priority = Number.isFinite(priority) ? priority : 0;
      return false;
    }
    case 'disabled':
      provider.disabled = scalar(value).toLowerCase() === 'true';
      return false;
    case 'models':
      return true;
    default:
      return false;
  }
}

function applyModelField(model, field) {
  if (!field) return;
  const [key, value] = field;
  if (key === 'name') model.name = unquote(value);
  else if (key === 'alias') model.alias = unquote(value);
}

// openai-compatibility providers from config.yaml text, in file order:
// [{ name, prefix: string|null, priority: number, disabled: boolean, models: [{ name, alias }] }].
// An empty alias is the model's name, which is the id the engine serves it under.
export function parseCompatProviders(configText) {
  const providers = [];
  if (typeof configText !== 'string') return providers;

  let inCompatibility = false;
  let inModels = false;
  let provider = null;
  let model = null;

  for (const line of configText.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const indent = line.length - line.trimStart().length;

    if (indent === 0) {
      inCompatibility = trimmed.startsWith('openai-compatibility:');
      continue;
    }
    if (!inCompatibility) continue;

    // "  - name: x": a new provider; its first key sits on the dash line.
    if (indent === 2 && line.startsWith('  - ')) {
      provider = { name: '', prefix: null, priority: 0, disabled: false, models: [] };
      providers.push(provider);
      model = null;
      inModels = applyProviderField(provider, splitField(line.slice(4).trim()));
      continue;
    }

    // "    key: value": the other provider keys. Reaching one ends the models list.
    if (provider && indent === 4) {
      inModels = applyProviderField(provider, splitField(trimmed));
      continue;
    }

    // "      - name: x" / "      - alias: x": a model entry starts.
    if (provider && inModels && indent === 6) {
      if (trimmed.startsWith('- ')) {
        model = { name: '', alias: '' };
        provider.models.push(model);
        applyModelField(model, splitField(trimmed.slice(2).trim()));
      }
      continue;
    }

    // "        alias: x": the other keys of the current model.
    if (provider && inModels && indent === 8 && model) {
      applyModelField(model, splitField(trimmed));
    }
  }

  for (const entry of providers) {
    entry.models = entry.models.filter((item) => item.name || item.alias);
    for (const item of entry.models) {
      if (!item.alias) item.alias = item.name;
    }
  }
  return providers;
}

// A prefix as the engine compares it: trimmed, without leading or trailing "/", lower case.
export const normalizePrefix = (value) => String(value ?? '').trim().replace(/^\/+|\/+$/g, '').trim().toLowerCase();

// A YAML scalar from the text after "prefix:": a quoted value up to its closing quote, otherwise
// everything before an inline "# comment" (and, in flow style, before the next "," or "}").
function prefixScalar(raw, flow) {
  const text = String(raw ?? '').trim();
  const quote = text[0];
  if (quote === '"' || quote === "'") {
    const end = text.indexOf(quote, 1);
    return end > 0 ? text.slice(1, end) : text.slice(1);
  }
  let value = text.replace(/(^|\s)#.*$/, '');
  if (flow) value = value.split(/[,}\]]/)[0];
  return value.trim();
}

// What a cleaned prefix must look like: one token, no spaces, quotes, YAML flow or comment
// characters, "/" or "\".
const PLAIN_PREFIX = /^[^\s"'`{}[\],#:/\\]+$/;

// A scanned value without the flow delimiters ("," "}" "]") a multiline flow mapping leaves after
// it, and without surrounding quotes.
function cleanPrefixValue(raw, flow) {
  let value = prefixScalar(raw, flow).trim();
  for (let previous = null; previous !== value;) {
    previous = value;
    value = value.replace(/[\s,}\]]+$/, '');
    const quoted = /^(["'])(.*)\1$/.exec(value);
    if (quoted) value = quoted[2].trim();
  }
  return normalizePrefix(value);
}

// Every routing prefix in config.yaml text, in file order: [{ section, prefix }], `prefix`
// normalized (normalizePrefix). null when some `prefix:` value is still not a plain token after
// cleaning: the inventory is then unreliable and is treated like an unreadable config (only pins
// fail closed, "pin-" heads are stripped). Deliberately broad so that it fails closed: every line whose key
// is exactly `prefix` counts, whatever its indentation or list style ("prefix: x",
// "- prefix: x", "  - {api-key: k, prefix: x}", "key: [{prefix: x}]"), switched-off entries and
// model-level keys included; keys that only contain the word (force-model-prefix, my-prefix)
// do not. `section` is the top-level key the line belongs to.
export function parseConfigPrefixes(configText) {
  const found = [];
  if (typeof configText !== 'string') return found;
  let section = null;
  let unreliable = false;
  const add = (raw, flow) => {
    const prefix = cleanPrefixValue(raw, flow);
    if (!prefix) return;
    if (!PLAIN_PREFIX.test(prefix)) unreliable = true;
    else found.push({ section, prefix });
  };
  for (const line of configText.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    if (line.length === line.trimStart().length) {
      const top = /^["']?([^"':#\s][^"':#]*?)["']?\s*:/.exec(trimmed);
      section = top ? top[1] : section;
    }
    const block = /^(?:-\s+)*["']?prefix["']?\s*:(?:\s+(.*))?$/.exec(trimmed);
    if (block) {
      add(block[1] ?? '', false);
      continue;
    }
    const flow = /[{,]\s*["']?prefix["']?\s*:\s*/g;
    for (let match = flow.exec(line); match; match = flow.exec(line)) {
      add(line.slice(match.index + match[0].length), true);
    }
  }
  return unreliable ? null : found;
}

// True when exactly one entry of `prefixes` (parseConfigPrefixes) uses `prefix`: only then does
// "<prefix>/<model>" reach that one provider. Without an inventory (null: the config could not
// be read) nothing is unique, so a pin fails closed.
export function isPrefixUnique(prefix, prefixes) {
  const wanted = normalizePrefix(prefix);
  if (!wanted || !Array.isArray(prefixes)) return false;
  return prefixes.filter((entry) => normalizePrefix(entry?.prefix) === wanted).length === 1;
}

// A client-sent model id without the routing prefixes in front of it: "pin-b/x", "PIN-B/x",
// "cc-pin-b/x" and "pin-b/pin-a/x" all become "x". Anything else is returned as it is.
// `prefixes` is the inventory (parseConfigPrefixes, or plain strings). null means the config
// could not be read: every head starting with "pin-" is then stripped as a backstop.
export function stripRoutingPrefixes(model, prefixes) {
  let value = String(model ?? '');
  const backstop = prefixes === null || prefixes === undefined;
  const known = new Set((Array.isArray(prefixes) ? prefixes : [])
    .map((entry) => normalizePrefix(typeof entry === 'string' ? entry : entry?.prefix))
    .filter(Boolean));
  const isRouting = (head) => (backstop ? head.startsWith('pin-') && head.length > 4 : known.has(head));
  if (!backstop && !known.size) return value;
  for (;;) {
    const slash = value.indexOf('/');
    if (slash <= 0) return value;
    let head = value.slice(0, slash).trim().toLowerCase();
    if (!isRouting(head) && head.startsWith('cc-')) head = head.slice(3);
    if (!isRouting(head)) return value;
    value = value.slice(slash + 1);
  }
}

// What the client asks for -> what the config calls it: lower case, no "cc-" prefix.
export const canonicalModel = (model) => String(model ?? '').trim().toLowerCase().replace(/^cc-/, '');

const compareText = (a, b) => (a < b ? -1 : a > b ? 1 : 0);

// The enabled providers that serve `model`, in the order the engine tries them: highest
// priority first, then by name. [{ name, prefix, priority, upstreamModel }].
export function providersForModel(providers, model) {
  const wanted = canonicalModel(model);
  if (!wanted || !Array.isArray(providers)) return [];
  const found = [];
  for (const provider of providers) {
    if (!provider || provider.disabled) continue;
    const served = (provider.models || []).find((item) => String(item?.alias || item?.name || '').toLowerCase() === wanted);
    if (!served) continue;
    found.push({
      name: provider.name,
      prefix: provider.prefix ?? null,
      priority: provider.priority ?? 0,
      upstreamModel: served.name,
    });
  }
  return found.sort((a, b) => (b.priority - a.priority)
    || compareText(a.name.toLowerCase(), b.name.toLowerCase())
    || compareText(a.name, b.name));
}

// The id that makes the engine use exactly this provider, or null if it has no prefix.
export function routeModelId(provider, model) {
  return provider?.prefix ? `${provider.prefix}/${model}` : null;
}

// True for "<prefix>/<something>" where <prefix> is some provider's prefix.
export function isInternalModelId(id, providers) {
  if (typeof id !== 'string' || !Array.isArray(providers)) return false;
  const slash = id.indexOf('/');
  if (slash <= 0) return false;
  const head = id.slice(0, slash);
  return providers.some((provider) => provider?.prefix && provider.prefix === head);
}

// The engine's `GET /v0/management/openai-compatibility` list -> the parseCompatProviders shape.
export function compatProvidersFromManagement(list) {
  if (!Array.isArray(list)) return [];
  return list.filter((entry) => entry && typeof entry === 'object').map((entry) => {
    const priority = Number(entry.priority);
    return {
      name: String(entry.name ?? ''),
      prefix: entry.prefix ? String(entry.prefix) : null,
      priority: Number.isInteger(priority) ? priority : 0,
      disabled: entry.disabled === true,
      models: (Array.isArray(entry.models) ? entry.models : [])
        .map((model) => ({ name: String(model?.name ?? ''), alias: String(model?.alias ?? '') }))
        .filter((model) => model.name || model.alias)
        .map((model) => ({ name: model.name, alias: model.alias || model.name })),
    };
  });
}

// Everything that serves each model, keyed by the lower-case model id:
// { [model]: [{ id, kind: 'compat'|'oauth', priority }] }. A compat provider's id is its name;
// `pools` are OAuth account pools [{ id: 'oauth:<provider>', priority, models: [model ids] }].
export function buildServingByModel(providers, pools = []) {
  const serving = {};
  const add = (model, entry) => {
    const key = String(model ?? '').trim().toLowerCase();
    if (!key) return;
    const list = serving[key] || (serving[key] = []);
    if (!list.some((item) => item.id === entry.id)) list.push(entry);
  };
  for (const provider of Array.isArray(providers) ? providers : []) {
    if (!provider || provider.disabled || !provider.name) continue;
    for (const model of provider.models || []) {
      add(model.alias || model.name, { id: provider.name, kind: 'compat', priority: provider.priority ?? 0 });
    }
  }
  for (const pool of Array.isArray(pools) ? pools : []) {
    for (const model of pool.models || []) add(model, { id: pool.id, kind: 'oauth', priority: pool.priority ?? 0 });
  }
  return serving;
}

// Where a value may go, given the run's neighbours and each entry's own bounds: the highest
// (ub) and lowest (lb) value position i can take in a strictly descending run that stays below
// `upper` and above `lower`. Each bound remembers which constraint set it ({ model, pool }).
function envelope(entries, upper, lower) {
  const ub = [];
  const lb = [];
  for (let i = 0; i < entries.length; i += 1) {
    const prev = i ? { value: ub[i - 1].value - 1, src: ub[i - 1].src } : { value: upper.value - 1, src: upper.src };
    const own = { value: entries[i].hi.value - 1, src: entries[i].hi.src };
    ub.push(own.value < prev.value ? own : prev);
  }
  for (let i = entries.length - 1; i >= 0; i -= 1) {
    const next = i < entries.length - 1 ? { value: lb[i + 1].value + 1, src: lb[i + 1].src } : { value: lower.value + 1, src: lower.src };
    const own = { value: entries[i].lo.value + 1, src: entries[i].lo.src };
    lb[i] = own.value > next.value ? own : next;
  }
  const broken = entries.findIndex((_, i) => lb[i].value > ub[i].value);
  return { ub, lb, broken: broken < 0 ? null : (lb[broken].src || ub[broken].src) };
}

// Strictly descending integers for one run of free compat entries between two fixed values
// (`upper` / `lower`: { value, src }, +/-Infinity at the ends), each entry also kept inside its
// own { lo, hi } from the pools of every model. Values that already fit are kept; otherwise the
// smallest contiguous window is renumbered, counting down from the largest old value in it
// (raised to leave room above the entry below), pulled into each position's allowed range.
// Among windows of the same size the highest one wins. Returns { values } or { broken: src }.
function renumber(entries, upper, lower) {
  const old = entries.map((entry) => entry.priority);
  const fits = (out) => out.every((value, i) => value < (i ? out[i - 1] : upper.value) && value > lower.value
    && value > entries[i].lo.value && value < entries[i].hi.value);
  if (fits(old)) return { values: old };
  const whole = envelope(entries, upper, lower);
  if (whole.broken) return { broken: whole.broken };
  for (let size = 1; size <= entries.length; size += 1) {
    for (let start = 0; start + size <= entries.length; start += 1) {
      const end = start + size - 1;
      const above = start > 0 ? { value: old[start - 1], src: null } : upper;
      const below = end < entries.length - 1 ? { value: old[end + 1], src: null } : lower;
      const window = entries.slice(start, end + 1);
      const { ub, lb, broken } = envelope(window, above, below);
      if (broken !== null || window.some((_, i) => lb[i].value > ub[i].value)) continue;
      const top = Math.max(...old.slice(start, end + 1), below.value + size);
      const out = old.slice();
      let prev = above.value;
      window.forEach((_, i) => {
        const value = Math.min(Math.max(top - i, lb[i].value), ub[i].value, prev - 1);
        out[start + i] = value;
        prev = value;
      });
      if (fits(out)) return { values: out };
    }
  }
  // Not expected to be reachable: the whole run always fits when its envelope does. Should it
  // happen anyway, say so instead of leaving these providers without a value.
  return { broken: whole.broken || UNSOLVED };
}

// A run renumber could not number although no pool is in the way.
const UNSOLVED = Object.freeze({ unsolved: true });
const UNSOLVED_REASON = '无法为这个顺序算出优先级，请刷新后再试';

const sign = (value) => (value > 0 ? 1 : value < 0 ? -1 : 0);
const crossing = (src) => (src && !src.unsolved ? `会改变 ${src.model} 中与登录账号 ${src.pool} 的先后` : UNSOLVED_REASON);

// New priorities for the compat providers of `targetModel` so that they are tried in `newOrder`
// (every id of the model, OAuth pools included, top first).
// - OAuth pools keep their priority. A compat provider that ties with a pool in any model
//   (the target included) keeps its value too (anchored); one above a pool anywhere stays above
//   it, one below stays below. These bounds are worked out before any value is chosen.
// - Entries with equal values may appear in either order. The free providers are numbered
//   strictly between the fixed ones, keeping old values where they already fit.
// - Rejected only when the order is impossible without crossing a pool; the reason names the
//   model and the pool. Anchored providers that must stay equal are listed in `ties`.
// - `affected`: other models whose order between compat providers changes (a tie counts as its
//   own order).
// Returns { priorities: { [compat id]: number }, affected: [model], ties: [[id]], rejected }.
export function planPriorityChange({ servingByModel, targetModel, newOrder } = {}) {
  const reject = (reason) => ({ priorities: {}, affected: [], ties: [], rejected: reason });
  const entries = Array.isArray(servingByModel?.[targetModel]) ? servingByModel[targetModel] : [];
  if (!entries.length) return reject(`没有供应商提供 ${targetModel}`);
  const byId = new Map(entries.map((entry) => [entry.id, entry]));
  if (!Array.isArray(newOrder) || newOrder.length !== byId.size || new Set(newOrder).size !== newOrder.length
    || !newOrder.every((id) => byId.has(id))) {
    return reject('顺序与当前的供应商列表不一致，请刷新后再试');
  }
  const models = Object.keys(servingByModel).filter((model) => Array.isArray(servingByModel[model])).sort();
  // Every value below is compared and counted with; one that is not a number cannot be planned.
  if (models.some((model) => servingByModel[model].some((item) => !Number.isSafeInteger(item?.priority)))) {
    return reject(UNSOLVED_REASON);
  }

  // Bounds of every compat provider of the target, from the pools of every model.
  const bounds = new Map();
  for (const entry of entries) {
    if (entry.kind !== 'oauth') bounds.set(entry.id, { anchor: null, lo: { value: -Infinity, src: null }, hi: { value: Infinity, src: null } });
  }
  for (const model of [targetModel, ...models.filter((model) => model !== targetModel)]) {
    const list = servingByModel[model];
    for (const pool of list.filter((item) => item.kind === 'oauth')) {
      const src = { model, pool: pool.id };
      for (const item of list) {
        const bound = item.kind !== 'oauth' && bounds.get(item.id);
        if (!bound) continue;
        const priority = byId.get(item.id).priority;
        if (priority === pool.priority) bound.anchor = bound.anchor || src;
        else if (priority > pool.priority && pool.priority >= bound.lo.value) bound.lo = { value: pool.priority, src };
        else if (priority < pool.priority && pool.priority <= bound.hi.value) bound.hi = { value: pool.priority, src };
      }
    }
  }

  // Walk the order: pools and anchored providers are fixed, the rest are numbered in between.
  const priorities = new Map();
  let run = [];
  let upper = { value: Infinity, src: null };
  const flush = (lower) => {
    const result = renumber(run, upper, lower);
    if (!result.values) return result.broken;
    run.forEach((entry, index) => priorities.set(entry.id, result.values[index]));
    run = [];
    return null;
  };
  for (const id of newOrder) {
    const entry = byId.get(id);
    const bound = bounds.get(id);
    if (entry.kind !== 'oauth' && !bound.anchor) {
      run.push({ id, priority: entry.priority, lo: bound.lo, hi: bound.hi });
      continue;
    }
    const fixed = { value: entry.priority, src: entry.kind === 'oauth' ? { model: targetModel, pool: id } : bound.anchor };
    if (fixed.value > upper.value) return reject(crossing(upper.src || fixed.src));
    const broken = flush(fixed);
    if (broken) return reject(crossing(broken));
    if (entry.kind !== 'oauth') priorities.set(id, entry.priority);
    upper = fixed;
  }
  const broken = flush({ value: -Infinity, src: null });
  if (broken) return reject(crossing(broken));

  // Compare every other model before and after; bounds make a pool change impossible, so this
  // is a last check, and it is what fills `affected`.
  const next = (entry) => (entry.kind !== 'oauth' && priorities.has(entry.id) ? priorities.get(entry.id) : entry.priority);
  const affected = [];
  for (const model of models) {
    if (model === targetModel) continue;
    const list = servingByModel[model];
    let changed = false;
    for (let i = 0; i < list.length; i += 1) {
      for (let j = i + 1; j < list.length; j += 1) {
        const [a, b] = [list[i], list[j]];
        if (a.kind === 'oauth' && b.kind === 'oauth') continue;
        if (sign(a.priority - b.priority) === sign(next(a) - next(b))) continue;
        const pool = a.kind === 'oauth' ? a : b.kind === 'oauth' ? b : null;
        if (pool) return reject(crossing({ model, pool: pool.id }));
        changed = true;
      }
    }
    if (changed) affected.push(model);
  }

  const result = {};
  const byValue = new Map();
  for (const id of newOrder) {
    if (byId.get(id).kind === 'oauth') continue;
    result[id] = priorities.get(id);
    if (!byValue.has(result[id])) byValue.set(result[id], []);
    byValue.get(result[id]).push(id);
  }
  // Last line of defence: a plan never hands out a value that is not an integer.
  if (!Object.values(result).every(Number.isSafeInteger)) return reject(UNSOLVED_REASON);
  const ties = [...byValue.values()].filter((group) => group.length > 1);
  return { priorities: result, affected, ties, rejected: null };
}
