// Where the gateway keeps its files, and the default ports.
//
// Every file lives under one data directory, OASES_DATA_DIR (default ./data, relative to the
// working directory of the process). The older per-file variables still override single paths:
// a non-empty value wins and is resolved against the working directory, an empty one means
// "not set".
import net from 'net';
import path from 'path';

export const DEFAULT_PORT = 8317;
export const DEFAULT_GO_BACKEND_URL = 'http://127.0.0.1:18316';

const file = (key, env, relative, kind, mode, createdBy, purpose) => (
  Object.freeze({ key, env, relative, kind, mode, createdBy, purpose })
);

// mode is the permission the file or directory is kept with (null: not enforced by this project).
// createdBy says who is expected to bring it into existence: the installer (before the gateway
// starts), bootstrap (the first-run script) or the gateway itself when it first needs it.
export const DATA_FILES = Object.freeze([
  file('configPath', 'CONFIG_PATH', 'config.yaml', 'file', null, 'installer',
    'Engine configuration (config.yaml). Normally set explicitly to the engine\'s own file.'),
  file('keyFilePath', 'KEY_FILE_PATH', 'secrets/cpa-management-key', 'file', 0o600, 'installer',
    'Management key that protects the admin routes. The gateway refuses to start without it.'),
  file('packEngineKeyPath', 'PACK_ENGINE_KEY_PATH', 'secrets/pack-engine-key', 'file', 0o600, 'bootstrap',
    'Internal engine key used on behalf of model-pack keys. It must also be listed in the engine\'s api-keys.'),
  file('packStoreKeyFile', 'PACK_STORE_KEY_FILE', 'secrets/pack-store-key', 'file', 0o600, 'bootstrap',
    'Key file for sealed copies of model-pack keys. This edition ships no cipher and seals nothing.'),
  file('permissionsPath', 'PERMISSIONS_PATH', 'permissions.json', 'file', 0o600, 'bootstrap',
    'Per-key access policy (schema 2).'),
  file('policyBackupDir', 'POLICY_BACKUP_DIR', 'backups/permissions', 'dir', 0o700, 'bootstrap',
    'Timestamped copies of permissions.json, taken before every policy write.'),
  file('configBackupDir', 'CONFIG_BACKUP_DIR', 'backups/config', 'dir', 0o700, 'gateway',
    'Timestamped copies of config.yaml, taken before a legacy file-mode config write (CPA_LEGACY_CONFIG_MUTATION=1 only).'),
  file('packsPath', 'PACKS_PATH', 'packs.json', 'file', 0o600, 'gateway',
    'Model packs and their keys.'),
  file('modelHealthPath', 'MODEL_HEALTH_PATH', 'model-health.json', 'file', 0o600, 'gateway',
    'Latest results of the model and provider health checks.'),
  file('apiKeyUsagePath', 'API_KEY_USAGE_PATH', 'api-key-usage.json', 'file', 0o600, 'gateway',
    'Per-key daily usage ledger.'),
  file('apiKeyUsageBackupPath', 'API_KEY_USAGE_BACKUP_PATH', 'api-key-usage.json.bak', 'file', 0o600, 'gateway',
    'Second copy of the usage ledger, written next to it. Follows API_KEY_USAGE_PATH when that is overridden.'),
  file('searchProvidersPath', 'SEARCH_PROVIDERS_PATH', 'search-providers.json', 'file', 0o600, 'gateway',
    'Web-search provider settings, including the provider API keys.'),
  file('searchUsagePath', 'SEARCH_USAGE_PATH', 'search-usage.json', 'file', 0o600, 'gateway',
    'Web-search daily usage counters.'),
  file('searchLogPath', 'SEARCH_LOG_PATH', 'logs/search-calls.jsonl', 'file', 0o600, 'gateway',
    'Web-search call log, one JSON object per line, rotated by size.'),
  file('backupStatusPath', 'BACKUP_STATUS_PATH', 'state/backup-status.json', 'file', null, 'installer',
    'Status file an external backup job may write (optional). Shown on the host status page when present.'),
  file('modelCatalogCachePath', 'MODEL_CATALOG_CACHE_PATH', 'model-catalog-cache.json', 'file', 0o600, 'gateway',
    'Cached public model metadata used to enrich /v1/models.'),
]);

const isSet = (value) => typeof value === 'string' && value !== '';

/**
 * Resolves every path the gateway uses. The result has `dataDir` and one field per DATA_FILES key.
 * `apiKeyUsageBackupPath` is the usage file plus ".bak" unless its own variable is set, so moving
 * the ledger moves its copy along.
 */
export function resolveGatewayPaths(env = process.env, cwd = process.cwd()) {
  const dataDir = path.resolve(cwd, isSet(env.OASES_DATA_DIR) ? env.OASES_DATA_DIR : 'data');
  const paths = { dataDir };
  for (const entry of DATA_FILES) {
    const override = env[entry.env];
    if (isSet(override)) {
      paths[entry.key] = path.resolve(cwd, override);
    } else if (entry.key === 'apiKeyUsageBackupPath') {
      // apiKeyUsagePath comes first in DATA_FILES, so it is already resolved here.
      paths[entry.key] = `${paths.apiKeyUsagePath}.bak`;
    } else {
      paths[entry.key] = path.join(dataDir, entry.relative);
    }
  }
  return Object.freeze(paths);
}

// True for the names and addresses that always mean "this machine". Another address of the host
// (a LAN IP, a container hostname) is not recognised: that needs a look at the network interfaces.
function pointsAtThisMachine(hostname) {
  const host = hostname.replace(/^\[|\]$/g, '').replace(/\.$/, '').toLowerCase();
  if (host === 'localhost' || host.endsWith('.localhost')) return true;
  if (net.isIPv4(host)) return host.startsWith('127.') || host === '0.0.0.0';
  if (net.isIPv6(host)) return host === '::1' || host === '::' || /^::ffff:7f[0-9a-f]{2}:[0-9a-f]{1,4}$/.test(host);
  return false;
}

/**
 * Throws when the engine address points back at one of the gateway's own listeners, which would
 * make every proxied request loop. `adminPort` is null when there is no separate admin listener.
 * An address that is not a URL is left to fail where it is used.
 */
export function assertBackendIsNotSelf({ port, adminPort, backendUrl }) {
  let target;
  try {
    target = new URL(backendUrl);
  } catch {
    return;
  }
  if (!pointsAtThisMachine(target.hostname)) return;
  const targetPort = Number(target.port || (target.protocol === 'https:' ? 443 : 80));
  for (const [role, own] of [['API', port], ['admin', adminPort]]) {
    if (own === null || own === undefined || own === '' || Number(own) !== targetPort) continue;
    // target.host carries no credentials, unlike the URL itself.
    throw new Error(`GO_BACKEND_URL points at ${target.host}, which is this gateway's own ${role} listener (port ${targetPort}). Set it to the address of the engine.`);
  }
}
