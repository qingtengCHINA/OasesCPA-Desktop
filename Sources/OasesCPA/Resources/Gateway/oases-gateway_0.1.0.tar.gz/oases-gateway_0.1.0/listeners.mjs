// Which listener answers what.
//
// Without ADMIN_LISTEN_PORT the gateway has one listener ("combined") that serves everything,
// exactly like the production gateway behind its reverse proxy, plus GET /healthz. With it, the
// API listener ("api", PORT) serves only /v1 and /v1/*, and the admin listener ("admin",
// ADMIN_LISTEN_PORT, always 127.0.0.1) serves only /cpa-admin/* and /healthz.
import fs from 'fs';

export const LISTENER_ROLES = Object.freeze(['combined', 'api', 'admin']);

const DEFAULT_VERSION_FILE = new URL('./VERSION', import.meta.url);

/**
 * Reads the release version (gateway/VERSION, trimmed). Throws when the file is missing,
 * unreadable or empty.
 */
export function readGatewayVersion(file = DEFAULT_VERSION_FILE) {
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (error) {
    throw new Error(`Cannot read the VERSION file (${error.code || error.message})`);
  }
  const version = text.trim();
  if (!version) throw new Error('The VERSION file is empty');
  return version;
}

/**
 * ADMIN_LISTEN_PORT: unset or '' means no separate admin listener (null). Anything else must be
 * a plain decimal port number 1-65535 (no sign, leading zero, exponent or blanks) that differs
 * from PORT; otherwise this throws.
 */
export function parseAdminListenPort(value, port) {
  if (value === undefined || value === null || value === '') return null;
  const text = String(value);
  const number = /^[1-9][0-9]{0,4}$/.test(text) ? Number(text) : NaN;
  if (!(number >= 1 && number <= 65535)) {
    throw new Error(`ADMIN_LISTEN_PORT must be a port number from 1 to 65535, got ${JSON.stringify(text.slice(0, 32))}`);
  }
  if (number === Number(port)) {
    throw new Error(`ADMIN_LISTEN_PORT (${number}) must differ from PORT (${Number(port)})`);
  }
  return number;
}

// The path as the gateway's handler sees it: new URL() resolves dot segments, percent-encoded
// dots and backslashes, and reads "//x/..." as a host. null when it is not a path at all.
function resolvedPath(pathname) {
  try {
    return new URL(pathname, 'http://gateway.invalid').pathname;
  } catch {
    return null;
  }
}

// A "." or ".." segment once percent-decoded (with "\" read as "/"), as a server further down
// may resolve it. An undecodable path counts as one.
function hasDotSegment(pathname) {
  let decoded;
  try {
    decoded = decodeURIComponent(pathname);
  } catch {
    return true;
  }
  return decoded.replace(/\\/g, '/').split('/').some((segment) => segment === '.' || segment === '..');
}

// True when the raw path, without dot segments, and the resolved one both satisfy `accepts`, so
// no spelling of a path can pass the check on one reading and be dispatched as another.
function bothReadings(pathname, accepts) {
  if (!accepts(pathname) || hasDotSegment(pathname)) return false;
  const resolved = resolvedPath(pathname);
  return resolved !== null && accepts(resolved);
}

// The bare path "/v1" is let through on purpose, although the engine has no "/v1" route and
// answers it with its own 404. Production's reverse proxy also lets exactly "/v1" through
// (`location = /v1`), so the gateway behaves the same. Do not "fix" it by refusing the path in
// this module or by adding a route for it on the engine side; the 404 is the intended answer.
const isV1 = (value) => value === '/v1' || value.startsWith('/v1/');
const isAdmin = (value) => value.startsWith('/cpa-admin/');

/**
 * Decides what a listener does with a request before anything else runs. `pathname` is the
 * request target without its query string, exactly as received (not normalised).
 * Returns 'continue' (the normal handler), 'healthz', 'not_found' or 'method_not_allowed'.
 */
export function routeForListener({ role, pathname, method }) {
  if (!LISTENER_ROLES.includes(role)) throw new Error(`Unknown listener role: ${role}`);
  const target = String(pathname || '');
  const healthMethod = method === 'GET' || method === 'HEAD' ? 'healthz' : 'method_not_allowed';
  if (role === 'combined') return target === '/healthz' ? healthMethod : 'continue';
  if (role === 'api') return bothReadings(target, isV1) ? 'continue' : 'not_found';
  if (target === '/healthz') return healthMethod;
  return bothReadings(target, isAdmin) ? 'continue' : 'not_found';
}

/**
 * Answers a request that routeForListener did not hand to the normal handler. Returns true when
 * it did.
 */
export function answerListenerRoute(route, req, res, version) {
  if (route === 'continue') return false;
  req.resume?.();
  if (route === 'healthz') {
    res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    res.end(req.method === 'HEAD' ? undefined : JSON.stringify({ ok: true, version }));
  } else if (route === 'method_not_allowed') {
    res.writeHead(405, { Allow: 'GET, HEAD' });
    res.end();
  } else {
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Not found' }));
  }
  return true;
}
