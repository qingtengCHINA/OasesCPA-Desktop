// Response rewriting for model packs: a pack key must only ever see the pack's
// public model id, never the real model, the provider behind it, or anything the
// upstream said about itself.
//
// Rules, all applied to JSON bodies and to every SSE data frame:
//   * `model` is replaced at the three places the served model is named:
//       { model } · { message: { model } } (Anthropic) · { response: { model } } (Responses)
//     Text the model generated is never touched.
//   * Provider-identifying fields (`provider`, `system_fingerprint`) are dropped.
//   * `error` objects (top level, `response.error`, `message.error`) are rebuilt
//     by safeError(): the upstream's wording is never repeated, and only
//     allow-listed `type` / `code` values survive.
//   * Anything that is not a JSON object is not relayed: a successful answer that
//     is HTML, text or truncated JSON is a failure of that member, and an SSE
//     `data:` payload that is neither JSON nor `[DONE]` is dropped.

function isPlainObject(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

// ------------------------------------------------------------------ errors

const SAFE_ERROR_TYPES = new Set([
  'invalid_request_error', 'authentication_error', 'permission_error', 'not_found_error', 'request_too_large',
  'rate_limit_error', 'overloaded_error', 'api_error', 'server_error', 'timeout_error', 'upstream_error',
]);

const SAFE_ERROR_CODES = new Map([
  ['context_length_exceeded', 'The input is too long for this model.'],
  ['content_filter', 'The request was blocked by a content filter.'],
  ['rate_limit_exceeded', 'The model is busy. Please retry shortly.'],
  ['invalid_request_error', 'The request was rejected by the model.'],
  ['invalid_value', 'The request was rejected by the model.'],
  ['unsupported_value', 'The request was rejected by the model.'],
  ['unsupported_parameter', 'The request was rejected by the model.'],
  ['missing_required_parameter', 'The request was rejected by the model.'],
  ['string_above_max_length', 'The request was rejected by the model.'],
  ['array_above_max_length', 'The request was rejected by the model.'],
  ['server_error', 'The model returned an error.'],
  ['overloaded', 'The model is busy. Please retry shortly.'],
  ['stream_interrupted', 'The stream was interrupted.'],
  ['stream_idle_timeout', 'The stream stalled and was closed.'],
]);

function defaultMessage(status) {
  if (status === 413) return 'The request is too large.';
  if (status === 400 || status === 422) return 'The request was rejected by the model.';
  return 'The model returned an error.';
}

/**
 * A fresh `{ message, type, code }` for an upstream error of any shape. Nothing
 * from the upstream's own message is kept: it can name the provider, a URL, a
 * request id or even quote a credential.
 */
export function safeError(raw, { status = 0, fallbackType = 'upstream_error' } = {}) {
  const source = isPlainObject(raw) ? raw : {};
  const code = typeof source.code === 'string' && SAFE_ERROR_CODES.has(source.code) ? source.code : null;
  let type = typeof source.type === 'string' && SAFE_ERROR_TYPES.has(source.type) ? source.type : null;
  if (!type) type = status >= 400 && status < 500 ? 'invalid_request_error' : fallbackType;
  return { message: (code && SAFE_ERROR_CODES.get(code)) || defaultMessage(status), type, code };
}

// ----------------------------------------------------------------- estimates

// CJK, Hangul, kana, full-width forms and emoji take roughly a token per character;
// other text takes a token per few characters. Used only where the upstream's own
// count is missing, so it leans high rather than low.
function isWide(code) {
  return (code >= 0x1100 && code <= 0x11ff) || (code >= 0x2e80 && code <= 0xa4cf) || (code >= 0xac00 && code <= 0xd7af)
    || (code >= 0xf900 && code <= 0xfaff) || (code >= 0xfe30 && code <= 0xfe4f) || (code >= 0xff00 && code <= 0xffef)
    || (code >= 0x1f300 && code <= 0x1faff) || (code >= 0x20000 && code <= 0x3ffff);
}

export function estimateTokens(text, { asciiPerToken = 3 } = {}) {
  if (typeof text !== 'string' || !text) return 0;
  let wide = 0;
  let narrow = 0;
  for (const ch of text) {
    if (isWide(ch.codePointAt(0))) wide += 1;
    else narrow += ch.length;
  }
  return wide + Math.ceil(narrow / asciiPerToken);
}

// ------------------------------------------------------------------ objects

export function rewriteModelInObject(value, externalId) {
  if (!isPlainObject(value)) return value;
  for (const target of [value, value.message, value.response]) {
    if (isPlainObject(target) && typeof target.model === 'string') target.model = externalId;
  }
  delete value.provider;
  delete value.system_fingerprint;
  // `"error": null` (or false) is how many providers say "no error": only a real error is rebuilt.
  if (value.error) value.error = safeError(value.error);
  if (isPlainObject(value.response) && value.response.error) value.response.error = safeError(value.response.error);
  if (isPlainObject(value.message) && value.message.error) value.message.error = safeError(value.message.error);
  // The Responses API reports a stream failure as a flat `{ type: "error", code, message, param }`.
  if (value.type === 'error' && typeof value.message === 'string') {
    const clean = safeError({ code: value.code });
    value.message = clean.message;
    value.code = clean.code;
    delete value.param;
  }
  return value;
}

/** The rewritten JSON text, or null when `text` is not a JSON object. */
export function rewriteJsonText(text, externalId) {
  if (typeof text !== 'string' || !text) return null;
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    return null;
  }
  if (!isPlainObject(parsed)) return null;
  return JSON.stringify(rewriteModelInObject(parsed, externalId));
}

// -------------------------------------------------------------------- SSE

const FRAME_BREAK = /\r\n\r\n|\n\n|\r\r/;
const LINE_BREAK = /\r\n|\r|\n/;
const DEFAULT_MAX_FRAME_CHARS = 1024 * 1024;

// Generated text in one frame (answer, reasoning, tool-call arguments), for estimating the
// output of a stream that ended without a final usage report.
function generatedStrings(obj) {
  const out = [];
  const add = (value) => { if (typeof value === 'string' && value) out.push(value); };
  if (Array.isArray(obj.choices)) {
    for (const choice of obj.choices) {
      const delta = choice?.delta;
      if (!isPlainObject(delta)) continue;
      add(delta.content);
      add(delta.reasoning_content);
      add(delta.function_call?.arguments);
      if (Array.isArray(delta.tool_calls)) for (const call of delta.tool_calls) add(call?.function?.arguments);
    }
  }
  if (isPlainObject(obj.delta)) {
    add(obj.delta.text);
    add(obj.delta.partial_json);
    add(obj.delta.thinking);
  } else {
    add(obj.delta); // Responses API: output_text.delta / function_call_arguments.delta carry a plain string
  }
  return out;
}

// True for the frame that carries a message's FINAL usage: an OpenAI chat usage chunk, an
// Anthropic message_delta, a Responses `response.completed`. The usage in an Anthropic
// message_start sits under `message` and is only the beginning, so it does not count.
function carriesFinalUsage(obj) {
  const reports = (usage) => isPlainObject(usage) && (Number.isFinite(usage.completion_tokens) || Number.isFinite(usage.output_tokens));
  return reports(obj.usage) || reports(obj.response?.usage);
}

// One complete frame in, the rewritten frame out ('' when it must not be relayed).
function rewriteFrame(frame, externalId, stats) {
  const eol = LINE_BREAK.exec(frame)?.[0] ?? '\n';
  // Only the standard SSE fields are relayed; anything else is not part of the protocol.
  const lines = frame.split(LINE_BREAK).filter((line) => !line || line.startsWith(':') || /^(data|event|id|retry)(:|$)/.test(line));
  const dataAt = [];
  const payload = [];
  lines.forEach((line, index) => {
    if (!line.startsWith('data:')) return;
    dataAt.push(index);
    payload.push(line.slice(5).replace(/^ /, ''));
  });
  if (!dataAt.length) return frame; // comments, bare events
  const joined = payload.join('\n');
  let replacement = null;
  if (joined.trim() === '[DONE]') {
    return frame;
  }
  if (joined.trimStart().startsWith('{')) {
    try {
      const parsed = JSON.parse(joined);
      if (isPlainObject(parsed)) {
        for (const text of generatedStrings(parsed)) {
          stats.textChars += text.length;
          stats.textTokens += estimateTokens(text);
        }
        if (carriesFinalUsage(parsed)) stats.finalUsage = true;
        replacement = `data: ${JSON.stringify(rewriteModelInObject(parsed, externalId))}`;
      }
    } catch {
      replacement = null;
    }
  }
  const keep = lines.filter((_, index) => !dataAt.includes(index));
  if (replacement === null) {
    // Neither JSON nor [DONE]: the payload is dropped; comment / event lines may stay.
    return keep.length ? keep.join(eol) : '';
  }
  const out = [...keep];
  out.splice(Math.min(dataAt[0], out.length), 0, replacement);
  return out.join(eol);
}

// Server-sent events arrive in arbitrary chunks. Frames are rewritten only once
// complete; whatever is incomplete waits in the buffer for the next push(), up to
// maxFrameChars, beyond which push() throws rather than grow without limit.
export function createSseModelRewriter(externalId, { maxFrameChars = DEFAULT_MAX_FRAME_CHARS } = {}) {
  const decoder = new TextDecoder('utf-8');
  const stats = { textChars: 0, textTokens: 0, finalUsage: false };
  let buffer = '';
  const emit = (frame, separator) => {
    const rewritten = rewriteFrame(frame, externalId, stats);
    return rewritten === '' ? '' : rewritten + separator;
  };
  return {
    stats,
    push(chunk) {
      buffer += typeof chunk === 'string' ? chunk : decoder.decode(chunk, { stream: true });
      let out = '';
      for (;;) {
        const match = FRAME_BREAK.exec(buffer);
        if (!match) break;
        out += emit(buffer.slice(0, match.index), match[0]);
        buffer = buffer.slice(match.index + match[0].length);
      }
      if (buffer.length > maxFrameChars) throw new Error('SSE frame too large');
      return out;
    },
    flush() {
      buffer += decoder.decode();
      const rest = buffer;
      buffer = '';
      return rest ? rewriteFrame(rest, externalId, stats) : '';
    },
  };
}

// ------------------------------------------------------------------- text

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// Replaces a real model name in free text, case-insensitively, including the
// `cc-` and `provider/` spellings the gateway accepts. Only used for text the
// gateway itself produces; upstream wording is never relayed (see safeError).
export function sanitizeText(text, realModels, externalId) {
  if (typeof text !== 'string') return '';
  const names = [...new Set((realModels || []).filter((name) => typeof name === 'string' && name.trim()).map((name) => name.trim()))]
    .sort((a, b) => b.length - a.length);
  let out = text;
  for (const name of names) {
    const pattern = new RegExp(`(?<![A-Za-z0-9_])(?:cc-)?(?:[A-Za-z0-9._-]+/)?${escapeRegExp(name)}(?![A-Za-z0-9])`, 'gi');
    out = out.replace(pattern, () => externalId);
  }
  return out;
}
