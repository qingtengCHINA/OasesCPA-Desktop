// Sealed copies of pack keys are not part of this gateway.
//
// Pack keys are stored as a hash only. The production gateway can additionally keep an
// encrypted copy of a key for its owner; that feature is not published. Without a cipher the
// pack store keeps no copy, and every view reports a key as not copyable.

/** Always null: there is no cipher, whatever key file is configured. */
export function createKeyCipher(options = {}) {
  void options;
  return null;
}
